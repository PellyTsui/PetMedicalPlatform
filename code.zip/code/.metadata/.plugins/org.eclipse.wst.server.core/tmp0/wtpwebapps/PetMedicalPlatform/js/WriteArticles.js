function checkTitle(){
	 var idField = document.getElementById("title");  
     if(idField.value==""){
     	document.getElementById("titleinfo").innerHTML="<font color='red'>请填写标题";
     	return false;
     }else{
    	 document.getElementById("titleinfo").innerHTML="";
    	 return true;
     }
 }

function checkTag1(){
	 var idField = document.getElementById("tag1");  
    if(idField.value==""){
    	document.getElementById("tag1info").innerHTML="<font color='red'>请选择标签";
    	return false;
    }else{
   	 document.getElementById("tag1info").innerHTML="";
   	 return true;
    }
}

function checkTag2(){
	 var idField = document.getElementById("tag2");  
   if(idField.value==""){
   	document.getElementById("tag2info").innerHTML="<font color='red'>请选择标签";
   	return false;
   }else{
  	 document.getElementById("tag2info").innerHTML="";
  	 return true;
   }
}

function checkContent(){
	 var idField = document.getElementById("content");  
  if(idField.value==""){
  	document.getElementById("contentinfo").innerHTML="<font color='red'>请填写文章内容";
  	return false;
  }else{
 	 document.getElementById("contentinfo").innerHTML="";
 	 return true;
  }
}

function checkall(){
	if(checkTitle()&&checkTag1()&&checkTag2()&&checkContent()){
		var btnSubmit = document.getElementById("submit");
		btnSubmit.disabled= "disabled";
		return true;
	}
	else{
		return false;
	}
}