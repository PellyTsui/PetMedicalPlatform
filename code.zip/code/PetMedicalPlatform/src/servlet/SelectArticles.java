package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Article;
import dao.UserDao;
import dao.UserDaoImpl;

/**
 * Servlet implementation class SelectArticles
 */
@WebServlet("/SelectArticles")
public class SelectArticles extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SelectArticles() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("utf-8");
		String tag1=request.getParameter("tag1");
		String tag2=request.getParameter("tag2");
		String type=request.getParameter("type");
		UserDao userDao=new UserDaoImpl();
		ArrayList<Article> articles=new ArrayList<Article>();
		System.out.println(tag1+" , "+tag2);
		if (tag1.equals("all")) {
			if (tag2.equals("all")) {
				articles=userDao.getAllArticles();
			}
			else{
				articles=userDao.selectArticlesTag2(tag2);
			}
		}
		else{
			if (tag2.equals("all")) {
				articles=userDao.selectArticlesTag1(tag1);
			}
			else{
				articles=userDao.selectArticleTag12(tag1, tag2);
			}
		}
		
		request.setAttribute("articles", articles);
		if (type.equals("1")) {
			request.getRequestDispatcher("AdminGetAllArticles.jsp").forward(request, response);
		}
		else if (type.equals("0")) {
			request.getRequestDispatcher("DrGetAllArticles.jsp").forward(request, response);
		}
		else if (type.equals("2")) {
			request.getRequestDispatcher("UserGetAllArticles.jsp").forward(request, response);
		}
			
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
