package servlet;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Answer;
import bean.Pet;
import bean.Query;
import dao.DoctorDao;
import dao.DoctorDaoImpl;
import dao.PetDao;
import dao.PetDaoImpl;
import dao.UserDao;
import dao.UserDaoImpl;

/**
 * Servlet implementation class DrGetQueryDetail
 */
@WebServlet("/DrGetQueryDetail")
public class DrGetQueryDetail extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DrGetQueryDetail() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String qid=request.getParameter("qid");
		System.out.println(qid);
		String act=request.getParameter("act");
		if (!act.equals("d3d9446802a44259755d38e6d163e820")&&!act.equals("c4ca4238a0b923820dcc509a6f75849b")&&!act.equals("6512bd43d9caa6e02c990b0a82652dca")&&!act.equals("c20ad4d76fe97759aa27a0c99bff6710")&&!act.equals("3c59dc048e8850243be8079a5c74d079")) {
			request.setAttribute("message", "�Ƿ�����");
			request.getRequestDispatcher("Error.jsp").forward(request, response);
		}else{
			Query query=null;
			DoctorDao doctorDao=new DoctorDaoImpl();
			query=doctorDao.getQueryDetail(Integer.parseInt(qid));

			if (query==null) {
				request.setAttribute("message", "�Ƿ�����");
				request.getRequestDispatcher("Error.jsp").forward(request, response);
			}else{
				PetDao petDao=new PetDaoImpl();
				int pid=query.getPid();
				System.out.println("query.getUsername: "+query.getUsername());
				Pet pet=new Pet();
				pet=petDao.getPetDetail(pid);
				String age="��������δ��";
	    	    String sex=pet.getPetSex();
				String petSex=pet.getPetSex();
				String petMix="��������";
				String petNeuter="δ����";
				if (petSex.equals("1")) {
					petSex="�к�";
				}else if (petSex.equals("0")) {
					petSex="Ů��";
				}else {
					petSex="����ȷ���Ա�";
				}
				Date birth=pet.getBirthdate();
				String sbirth=birth.toString();
				String days=petDao.getdays(sbirth);
				int years=Integer.parseInt(days)/360;
				int months=(Integer.parseInt(days)%360)/30;
				if(years!=0&&months!=0){
				   age=years+"��"+months+"����";
				   System.out.println(age);
				}
				if (years!=0&&months==0) {
					age=years+"��" ;
					System.out.println(age);
				}
				if (years==0&months!=0) {
					age=months+"����";
					System.out.println(age);
				}
				if (years==0&months==0) {
					age="δ����";
				}
				if (pet.getNeuter().equals("1")) {
					petMix="С��Ѫ";
				}
				if (pet.getNeuter().equals("0")) {
					petMix="����";
				}
				if (pet.getNeuter().equals("1")) {
					petNeuter="�Ѿ���";
				}
				
				request.setAttribute("petNeuter", petNeuter);
				request.setAttribute("petMix", petMix);
				request.setAttribute("pet", pet);
				request.setAttribute("age", age);
				request.setAttribute("sex", sex);
				request.setAttribute("petSex", petSex);
				request.setAttribute("query", query);
				request.setAttribute("act", act);
				if (act.equals("d3d9446802a44259755d38e6d163e820")||act.equals("c4ca4238a0b923820dcc509a6f75849b")) {
					request.getRequestDispatcher("DrGetQueryDetail.jsp").forward(request, response);
				}else if (act.equals("6512bd43d9caa6e02c990b0a82652dca")||act.equals("c20ad4d76fe97759aa27a0c99bff6710")||act.equals("3c59dc048e8850243be8079a5c74d079")) {
					UserDao userDao=new UserDaoImpl();
					Answer answer=userDao.getAnswerDetail(Integer.parseInt(qid));
					request.setAttribute("answer", answer);
					if (act.equals("3c59dc048e8850243be8079a5c74d079")) {
						request.getRequestDispatcher("DrAnswerDetail.jsp").forward(request, response);
					}else {
						  request.getRequestDispatcher("UserShowQueryDetail.jsp").forward(request, response);
					}		  

				}else {
					request.setAttribute("message", "�Ƿ�����");
					request.getRequestDispatcher("Error.jsp").forward(request, response);
				}
				
				
			}
		}

		
		
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
