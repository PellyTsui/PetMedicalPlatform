package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Doctor;
import dao.DoctorDao;
import dao.DoctorDaoImpl;
import utility.PasswordUtil;

/**
 * Servlet implementation class DoctorSignup
 */
@WebServlet("/DoctorSignup")
public class DoctorSignup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DoctorSignup() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
        request.setCharacterEncoding("UTF-8");
		DoctorDao doctorDao=new DoctorDaoImpl();
		String userName=request.getParameter("userName");
		String userPwd=request.getParameter("userPwd");
		String md5Pwd=PasswordUtil.generate(userPwd);
		String userMail=request.getParameter("userMail");
		String phoNum=request.getParameter("phoNum");
		String DrHosptl=request.getParameter("DrHosptl");
		String DrGoodAt=request.getParameter("DrGoodAt");
		String DrIntro=request.getParameter("DrIntro");
		String realname=request.getParameter("truename");
		System.out.println("servlet:"+userName);
		Doctor doctor=new Doctor(userName, md5Pwd, phoNum, userMail, DrHosptl, DrGoodAt, DrIntro,realname);
		doctorDao.addDoctor(doctor);
		String message="�ɹ�ע�ᣡ�뽫������Ϸ��������䣺 petmedical@163.com��ע����Ϣ������7�����������ظ�����ע������ʼ�";
		request.setAttribute("message", message);
		request.setAttribute("type", "5");
		request.getRequestDispatcher("message.jsp").forward(request, response);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
