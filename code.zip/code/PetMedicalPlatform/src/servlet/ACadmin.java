package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.AdminDao;
import dao.AdminDaoImpl;

/**
 * Servlet implementation class ACadmin
 */
@WebServlet("/ACadmin")
public class ACadmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ACadmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");
		String state=request.getParameter("state");
		String type=request.getParameter("type");
		String username=request.getParameter("username");
		AdminDao adminDao=new AdminDaoImpl();
		if (type.equals("1")) {
			adminDao.changeUserState(username, Integer.parseInt(state));
		}else if (type.equals("2")) {
			adminDao.changeDrState(Integer.parseInt(username), Integer.parseInt(state));
		}
		request.setAttribute("state", state);
		request.setAttribute("type", type);
	    request.getRequestDispatcher("ACmanagement").forward(request, response);
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
