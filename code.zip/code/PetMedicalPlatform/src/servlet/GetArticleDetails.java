package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Article;
import dao.DoctorDao;
import dao.DoctorDaoImpl;

/**
 * Servlet implementation class GetArticleDetails
 */
@WebServlet("/GetArticleDetails")
public class GetArticleDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetArticleDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String aid=request.getParameter("aid");
		String type=request.getParameter("type");
		
		DoctorDao doctorDao=new DoctorDaoImpl();
		Article article=doctorDao.getArticleDetail(Integer.parseInt(aid));
		if (article==null) {
			String message="�Ƿ�����";
			request.setAttribute("message", message);
			request.getRequestDispatcher("Error.jsp").forward(request, response);
		}else{
			request.setAttribute("article", article);
			if (type.equals("3c59dc048e8850243be8079a5c74d079")) {
				request.getRequestDispatcher("UserShowArticleDetails.jsp").forward(request, response);
			}
			else if (type.equals("c4ca4238a0b923820dcc509a6f75849b")) {
				request.getRequestDispatcher("AdminShowArticleDetails.jsp").forward(request, response);
			}
			else if (type.equals("c81e728d9d4c2f636f067f89cc14862c")) {
				request.getRequestDispatcher("DrGetAllArticleDetail.jsp").forward(request, response);
			}
			else if (type.equals("eccbc87e4b5ce2fe28308fd9f2a7baf3")) {
				request.getRequestDispatcher("DrShowArticleDetails.jsp").forward(request, response);
			}
			else {
				String message="�Ƿ�����";
				request.setAttribute("message", message);
				request.getRequestDispatcher("Error.jsp").forward(request, response);
			}
				
		}

		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
