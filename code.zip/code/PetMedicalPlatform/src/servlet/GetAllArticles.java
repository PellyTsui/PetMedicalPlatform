package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Article;
import dao.UserDao;
import dao.UserDaoImpl;

/**
 * Servlet implementation class GetAllArticles
 */
@WebServlet("/GetAllArticles")
public class GetAllArticles extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetAllArticles() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String type=request.getParameter("type");
		UserDao userDao=new UserDaoImpl();
		ArrayList<Article> articles=userDao.getAllArticles();
		request.setAttribute("articles", articles);
		if (type.equals("1")) {
			request.getRequestDispatcher("AdminGetAllArticles.jsp").forward(request, response);
		}
		else if (type.equals("0")) {
			request.getRequestDispatcher("DrGetAllArticles.jsp").forward(request, response);
		}
		else if (type.equals("2")) {
			request.getRequestDispatcher("UserGetAllArticles.jsp").forward(request, response);
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
