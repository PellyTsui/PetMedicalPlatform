package dao;

import java.util.ArrayList;

import bean.Admin;
import bean.Answer;
import bean.Doctor;

public interface AdminDao {
	   public ArrayList<Doctor> getDrList(int state);
	   public void changeDrState(int id,int state);
	   public void deleteSignup(int id);
	   public void deleteArticle(int aid);
	   public Admin getAdminInfo(String name,String pwd);
	   public ArrayList<String> getUserList(int state);
	   public void changeUserState(String username, int state);
       public void lockAnswer(int Taid,int TrId);
       public ArrayList<Answer> getAnswerList();
	   
	   
	   
	   
	  
	

}
