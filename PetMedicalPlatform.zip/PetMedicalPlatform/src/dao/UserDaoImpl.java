package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import bean.User;

public class UserDaoImpl implements UserDao{

	@Override
	public void addUser(User user) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("addUser method begins");
		String sql1="select max(UserId) from user";
		int userId=-1;
		
		try {
			PreparedStatement ps1=conn.prepareStatement(sql1);
			ResultSet rs1=ps1.executeQuery();
			if (rs1.next()) {
				 userId=rs1.getInt(1);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	    String sql="insert into user(Username,UserPwd,UserMail,PhoNum,activated,UserId) values (?,?,?,?,?,?)";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setString(1, user.getUsername());
	    	ps.setString(2, user.getUserPwd());
	    	ps.setString(3, user.getUserMail());
	    	ps.setString(4, user.getPhoNum());
	    	ps.setBoolean(5, false);
	    	ps.setInt(6, userId+1);
	    	int row=ps.executeUpdate();
	    	if (row>0) {
	    		System.out.println("Success to addUser");
			ps.close();	
			}
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
			System.out.println("Fail to addUser");
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
			System.out.println("addUser method ends");
		}
	}

	
	@Override
	public boolean isUserExist(String username) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		String sql="select * from user where Username=?";
		System.out.println("isUserExist method begins");
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, username);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				return true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("error appears!!! ");
		}finally {
			ConnectDB.closeConnection(conn);   
			System.out.println("isUserExist method ends");
		}
		return false;
	}

	@Override
	public User getUserInfo(String userName, String userPwd) {
		// TODO Auto-generated method stub
		User user=null;
		Connection conn=ConnectDB.getConnection();
		String sql="select * from user where Username=? and UserPwd=? and activated=1";
		System.out.println("getUserInfo begins");
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, userName);
			ps.setString(2, userPwd);
			System.out.println(sql);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				user=new User();
				user.setUsername(userName);
				user.setUserPwd(userPwd);
				user.setUserMail(rs.getString("UserMail"));
				user.setPhoNum(rs.getString("PhoNum"));
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Fail to getUserInfo");
		}finally {
			ConnectDB.closeConnection(conn);
			System.out.println("getUserInfo method ends");
		}
		return user;
	}

	
	@Override
	public void changePwd(String userName,String userPwd) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		String sql="update user set UserPwd =? where Username=?";
		System.out.println("changePwd method begins");
		try{
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, userPwd);
			ps.setString(2, userName);
			ps.executeUpdate();
			ps.close();
		}catch(Exception e){
			
			System.out.print("Fail to changePwd");
		}finally{
			ConnectDB.closeConnection(conn);
			System.out.println("changePwd method ends");
		}
		
	}

	@Override
	public User findUserById(int userId) {
		// TODO Auto-generated method stub
		Connection conn = ConnectDB.getConnection();
		System.out.println("findUserById begins");
		String sql = "select * from user where UserId = ?";
		User user = new User();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, userId);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				user.setUsername(rs.getString("Username"));
				user.setUserPwd(rs.getString("UserPwd"));
				user.setUserMail(rs.getString("UserMail"));
				user.setPhoNum(rs.getString("PhoNum"));
				user.setUserId(userId);
				user.setActivated(rs.getBoolean("activated"));
				user.setRandomCode(rs.getString("randomCode"));
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		return user;
	}

	@Override
	public User findUserByName(String userName) {
		// TODO Auto-generated method stub

		Connection conn = ConnectDB.getConnection();
		String sql = "select * from user where Username = ?";
		User user = new User();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, userName);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				user.setUsername(userName);
				user.setUserPwd(rs.getString("UserPwd"));
				user.setUserMail(rs.getString("UserMail"));
				user.setPhoNum(rs.getString("PhoNum"));
				user.setUserId(rs.getInt("UserId"));
				user.setActivated(rs.getBoolean("activated"));
				user.setRandomCode(rs.getString("randomCode"));
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		return user;
	}

	@Override
	public User findUserByNameOrEmail(String nameOrEmail) {
		// TODO Auto-generated method stub
		Connection conn = ConnectDB.getConnection();
		String sql = "select * from user where Username = ?";
		User user = new User();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, nameOrEmail);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				user.setUsername(nameOrEmail);
				user.setUserPwd(rs.getString("UserPwd"));
				user.setUserMail(rs.getString("UserMail"));
				user.setPhoNum(rs.getString("PhoNum"));
				user.setUserId(rs.getInt("UserId"));
				user.setActivated(rs.getBoolean("activated"));
				user.setRandomCode(rs.getString("randomCode"));
			}
			else{
				sql="select * from user where UserMail = ?";
				PreparedStatement ps1=conn.prepareStatement(sql);
				ResultSet rs1=ps1.executeQuery();
				if (rs.next()) {
					user.setUsername("Username");
					user.setUserPwd(rs.getString("UserPwd"));
					user.setUserMail(rs.getString(nameOrEmail));
					user.setPhoNum(rs.getString("PhoNum"));
					user.setUserId(rs.getInt("UserId"));
					user.setActivated(rs.getBoolean("activated"));
					user.setRandomCode(rs.getString("randomCode"));
				}
				rs1.close();
				ps1.close();
			}
			rs.close();
		
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		return user;
	}

	@Override
	public void updateUserRandomCode(int userId, String randomCode) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
	    String sql="update user set randomCode=? where userId=?";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setString(1, randomCode);
	    	ps.setInt(2, userId);
	    	
	        ps.executeUpdate();
	    	
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
	
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
		}
		
	}

	@Override
	public boolean isEmailExist(String mail) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		String sql="select * from user where UserMail=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, mail);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				System.out.println("isEmailExists true");
				return true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("error appears!!! ");
		}finally {
			ConnectDB.closeConnection(conn);   
		}
		return false;
		
	}

	@Override
	public void updateUserActivate(int userId) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("updateUserActivatie begins");
	    String sql="update user set activated=? where userId=?";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setBoolean(1, true);
	    	ps.setInt(2, userId);
	    	
	        ps.executeUpdate();
	    	
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
	
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
		}
	}


	
	

}
