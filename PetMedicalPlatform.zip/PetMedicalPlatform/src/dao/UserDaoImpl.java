package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import bean.Answer;
import bean.Article;
import bean.Query;
import bean.User;

public class UserDaoImpl implements UserDao{

	@Override
	public void addUser(User user) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("addUser method begins");
		String sql1="select max(UserId) from user";
		int userId=-1;
		
		try {
			PreparedStatement ps1=conn.prepareStatement(sql1);
			ResultSet rs1=ps1.executeQuery();
			if (rs1.next()) {
				 userId=rs1.getInt(1);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	    String sql="insert into user(Username,UserPwd,UserMail,PhoNum,activated,UserId) values (?,?,?,?,?,?)";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setString(1, user.getUsername());
	    	ps.setString(2, user.getUserPwd());
	    	ps.setString(3, user.getUserMail());
	    	ps.setString(4, user.getPhoNum());
	    	ps.setBoolean(5, false);
	    	ps.setInt(6, userId+1);
	    	int row=ps.executeUpdate();
	    	if (row>0) {
	    		System.out.println("Success to addUser");
			ps.close();	
			}
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
			System.out.println("Fail to addUser");
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
			System.out.println("addUser method ends");
		}
	}

	
	@Override
	public boolean isUserExist(String username) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		String sql="select * from user where Username=?";
		System.out.println("isUserExist method begins");
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, username);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				return true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("error appears!!! ");
		}finally {
			ConnectDB.closeConnection(conn);   
			System.out.println("isUserExist method ends");
		}
		return false;
	}

	@Override
	public User getUserInfo(String userName) {
		// TODO Auto-generated method stub
		User user=null;
		Connection conn=ConnectDB.getConnection();
		String sql="select * from user where Username=? and activated=1";
		System.out.println("getUserInfo begins");
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, userName);
			System.out.println(sql);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				user=new User();
				user.setUsername(userName);
				user.setUserPwd(rs.getString("UserPwd"));
				user.setUserMail(rs.getString("UserMail"));
				user.setPhoNum(rs.getString("PhoNum"));
				user.setImage(rs.getString("image"));
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Fail to getUserInfo");
		}finally {
			ConnectDB.closeConnection(conn);
			System.out.println("getUserInfo method ends");
		}
		return user;
	}

	
	@Override
	public void changePwd(String userName,String userPwd) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		String sql="update user set UserPwd =? where Username=?";
		System.out.println("changePwd method begins");
		try{
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, userPwd);
			ps.setString(2, userName);
			ps.executeUpdate();
			ps.close();
		}catch(Exception e){
			
			System.out.print("Fail to changePwd");
		}finally{
			ConnectDB.closeConnection(conn);
			System.out.println("changePwd method ends");
		}
		
	}

	@Override
	public User findUserById(int userId) {
		// TODO Auto-generated method stub
		Connection conn = ConnectDB.getConnection();
		System.out.println("findUserById begins");
		String sql = "select * from user where UserId = ?";
		User user = new User();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, userId);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				user.setUsername(rs.getString("Username"));
				user.setUserPwd(rs.getString("UserPwd"));
				user.setUserMail(rs.getString("UserMail"));
				user.setPhoNum(rs.getString("PhoNum"));
				user.setUserId(userId);
				user.setActivated(rs.getBoolean("activated"));
				user.setRandomCode(rs.getString("randomCode"));
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		return user;
	}

	@Override
	public User findUserByName(String userName) {
		// TODO Auto-generated method stub

		Connection conn = ConnectDB.getConnection();
		String sql = "select * from user where Username = ?";
		User user = new User();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, userName);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				user.setUsername(userName);
				user.setUserPwd(rs.getString("UserPwd"));
				user.setUserMail(rs.getString("UserMail"));
				user.setPhoNum(rs.getString("PhoNum"));
				user.setUserId(rs.getInt("UserId"));
				user.setActivated(rs.getBoolean("activated"));
				user.setRandomCode(rs.getString("randomCode"));
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		return user;
	}

	@Override
	public User findUserByNameOrEmail(String nameOrEmail) {
		// TODO Auto-generated method stub
		Connection conn = ConnectDB.getConnection();
		String sql = "select * from user where Username = ?";
		User user = new User();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, nameOrEmail);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				user.setUsername(nameOrEmail);
				user.setUserPwd(rs.getString("UserPwd"));
				user.setUserMail(rs.getString("UserMail"));
				user.setPhoNum(rs.getString("PhoNum"));
				user.setUserId(rs.getInt("UserId"));
				user.setActivated(rs.getBoolean("activated"));
				user.setRandomCode(rs.getString("randomCode"));
			}
			else{
				sql="select * from user where UserMail = ?";
				PreparedStatement ps1=conn.prepareStatement(sql);
				ResultSet rs1=ps1.executeQuery();
				if (rs.next()) {
					user.setUsername("Username");
					user.setUserPwd(rs.getString("UserPwd"));
					user.setUserMail(rs.getString(nameOrEmail));
					user.setPhoNum(rs.getString("PhoNum"));
					user.setUserId(rs.getInt("UserId"));
					user.setActivated(rs.getBoolean("activated"));
					user.setRandomCode(rs.getString("randomCode"));
				}
				rs1.close();
				ps1.close();
			}
			rs.close();
		
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		return user;
	}

	@Override
	public void updateUserRandomCode(int userId, String randomCode) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
	    String sql="update user set randomCode=? where userId=?";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setString(1, randomCode);
	    	ps.setInt(2, userId);
	    	
	        ps.executeUpdate();
	    	
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
	
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
		}
		
	}

	@Override
	public boolean isEmailExist(String mail) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		String sql="select * from user where UserMail=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, mail);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				System.out.println("isEmailExists true");
				return true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("error appears!!! ");
		}finally {
			ConnectDB.closeConnection(conn);   
		}
		return false;
		
	}

	@Override
	public void updateUserActivate(int userId) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("updateUserActivatie begins");
	    String sql="update user set activated=? where userId=?";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setBoolean(1, true);
	    	ps.setInt(2, userId);
	    	
	        ps.executeUpdate();
	    	
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
	
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
		}
	}


	@Override
	public ArrayList<Article> getAllArticles() {
		// TODO Auto-generated method stub
		Connection conn = ConnectDB.getConnection();
		ArrayList<Article> articles=new ArrayList<Article >();
		String sql = "select * from article where state=0 ORDER BY date DESC";
		Article article=new Article(); 
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				int aid=rs.getInt("ArticleId");
				int did=rs.getInt("DrId");
				String title=rs.getString("title");
				String tag1=rs.getString("tag1");
				String tag2=rs.getString("tag2");
				String content=rs.getString("content");
				Date date=rs.getDate("date");
				String Drname=rs.getString("Drname");
				int state=rs.getInt("state");
				article=new Article(aid, did, title, tag1, tag2, content, Drname, state, date);
			   articles.add(article);	
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		
//		Iterator<Article> iterator=myArticles.iterator();
//		Article article1=new Article();
//		while(iterator.hasNext()){
//			article1=iterator.next();
//			System.out.println(article1.getAid());
//		}
//		
//		System.out.println("size:"+myArticles.size());
		return articles;
	}


	@Override
	public ArrayList<Article> selectArticlesTag1(String tag1) {
		// TODO Auto-generated method stub
		Connection conn = ConnectDB.getConnection();
		ArrayList<Article> articles=new ArrayList<Article >();
		String sql = "select * from article where tag1='"+tag1+"' and state=0 ORDER BY date DESC";
		System.out.println(sql);
		Article article=new Article(); 
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				int aid=rs.getInt("ArticleId");
				int did=rs.getInt("DrId");
				String title=rs.getString("title");
				String tag2=rs.getString("tag2");
				String content=rs.getString("content");
				Date date=rs.getDate("date");
				String Drname=rs.getString("Drname");
				int state=rs.getInt("state");
				article=new Article(aid, did, title, tag1, tag2, content, Drname, state, date);
			   articles.add(article);	
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		
//		Iterator<Article> iterator=myArticles.iterator();
//		Article article1=new Article();
//		while(iterator.hasNext()){
//			article1=iterator.next();
//			System.out.println(article1.getAid());
//		}
//		
//		System.out.println("size:"+myArticles.size());
		return articles;
	}


	@Override
	public ArrayList<Article> selectArticlesTag2(String tag2) {
		// TODO Auto-generated method stub
		Connection conn = ConnectDB.getConnection();
		ArrayList<Article> articles=new ArrayList<Article >();
		String sql = "select * from article where tag2='"+tag2+"' and state=0 ORDER BY date DESC";
		System.out.println(sql);
		Article article=new Article(); 
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				int aid=rs.getInt("ArticleId");
				int did=rs.getInt("DrId");
				String title=rs.getString("title");
				String tag1=rs.getString("tag1");
				String content=rs.getString("content");
				Date date=rs.getDate("date");
				String Drname=rs.getString("Drname");
				int state=rs.getInt("state");
				article=new Article(aid, did, title, tag1, tag2, content, Drname, state, date);
			   articles.add(article);	
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		
//		Iterator<Article> iterator=myArticles.iterator();
//		Article article1=new Article();
//		while(iterator.hasNext()){
//			article1=iterator.next();
//			System.out.println(article1.getAid());
//		}
//		
//		System.out.println("size:"+myArticles.size());
		return articles;
	}


	@Override
	public ArrayList<Article> selectArticleTag12(String tag1,String tag2) {
		// TODO Auto-generated method stub
		Connection conn = ConnectDB.getConnection();
		ArrayList<Article> articles=new ArrayList<Article >();
		String sql = "select * from article where tag1='"+tag1+"' and tag2='"+tag2+"' and state=0 ORDER BY date DESC";
		System.out.println(sql);
		Article article=new Article(); 
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				int aid=rs.getInt("ArticleId");
				int did=rs.getInt("DrId");
				String title=rs.getString("title");
				String content=rs.getString("content");
				Date date=rs.getDate("date");
				String Drname=rs.getString("Drname");
				int state=rs.getInt("state");
				article=new Article(aid, did, title, tag1, tag2, content, Drname, state, date);
			   articles.add(article);	
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		
//		Iterator<Article> iterator=myArticles.iterator();
//		Article article1=new Article();
//		while(iterator.hasNext()){
//			article1=iterator.next();
//			System.out.println(article1.getAid());
//		}
//		
//		System.out.println("size:"+myArticles.size());
		return articles;
	}


	@Override
	public void addQuery(String username, int pid, int type, int subtype, String title, String content) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		java.util.Date  date=new java.util.Date();
		java.sql.Date  date1=new java.sql.Date(date.getTime());
		System.out.println("addQuery method begins");
	    String sql="insert into trquestion(Username,pid,Trtype,TrSubtype,TrTitle,TrContent,date,state) values (?,?,?,?,?,?,?,?)";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setString(1, username);
	    	ps.setInt(2, pid);
	    	ps.setInt(3, type);
	    	ps.setInt(4, subtype);
	    	ps.setString(5, title);
	    	ps.setString(6, content);
	    	ps.setDate(7, date1);
	    	ps.setInt(8, 0);
	    	int row=ps.executeUpdate();
	    	if (row>0) {
	    		System.out.println("Success to addQuery");
			ps.close();	
			}
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
			System.out.println("Fail to addQuery");
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
			System.out.println("addQuery method ends");
		}
	}


	@Override
	public ArrayList<Query> getQueryList(String username) {
		// TODO Auto-generated method stub
		Connection conn = ConnectDB.getConnection();
		ArrayList<Query> queries=new ArrayList<Query>();
		String sql = "select * from trquestion where Username=? ORDER BY date DESC";
		System.out.println(sql);
		Query query=new Query(); 
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, username);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				int Trid=rs.getInt("TrId");
				int pid=rs.getInt("pid");
				int Trtype=rs.getInt("Trtype");
				int TrSubtype=rs.getInt("TrSubtype");
				String title=rs.getString("TrTitle");
				String content=rs.getString("TrContent");
				Date date=rs.getDate("date");
				int state=rs.getInt("state");
				query=new Query(Trid, username, pid, Trtype, TrSubtype, title, content, date,state);
				queries.add(query);	
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		
//		Iterator<Article> iterator=myArticles.iterator();
//		Article article1=new Article();
//		while(iterator.hasNext()){
//			article1=iterator.next();
//			System.out.println(article1.getAid());
//		}
//		
//		System.out.println("size:"+myArticles.size());
		return queries;
	}


	@Override
	public Query getQueryDetail(int TrId) {
		// TODO Auto-generated method stub
		Query query=null;
		Connection conn=ConnectDB.getConnection();
		String sql="select * from trquestion where TrId= ? ";
		System.out.println("getQueryDetail begins");
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setInt(1, TrId);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				query=new Query();
				query.setContent(rs.getString("TrContent"));
				query.setDate(rs.getDate("date"));
				query.setPid(rs.getInt("pid"));
				query.setState(rs.getInt("state"));
				query.setSubtype(rs.getInt("TrSubtype"));
				query.setTitle(rs.getString("TrTitle"));
				query.setTrId(TrId);
				query.setType(rs.getInt("Trtype"));
				query.setUsername(rs.getString("Username"));
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Fail to getQueryDetail");
		}finally {
			ConnectDB.closeConnection(conn);
			System.out.println("getQueryDetail method ends");
		}
		return query;
	}


	@Override
	public Answer getAnswerDetail(int TrId) {
		// TODO Auto-generated method stub
		Answer answer=null;
		Connection conn=ConnectDB.getConnection();
		String sql="select * from transwer where Trid= ? ";
		System.out.println("getAnswerDetail begins");
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setInt(1, TrId);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				answer=new Answer();
				answer.setDate(rs.getDate("date"));
				answer.setDid(rs.getInt("did"));
				answer.setUsername(rs.getString("Username"));
				answer.setDrName(rs.getString("drName"));
				answer.setPetid(rs.getInt("petId"));
				answer.setTacontent(rs.getString("tacontent"));
				answer.setTaid(rs.getInt("Taid"));
				answer.setTrid(TrId);
				

				
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Fail to getAnswerDetail");
		}finally {
			ConnectDB.closeConnection(conn);
			System.out.println("getAnswerDetail method ends");
		}
		return answer;
	}



	@Override
	public void addImage(String username, String imagename) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		String sql="update user set image =? where Username=?";
		System.out.println("updateImage method begins");
		try{
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, imagename);
			ps.setString(2, username);
			ps.executeUpdate();
			ps.close();
		}catch(Exception e){
			
			System.out.print("Fail to updateImage");
			System.out.println(e);
		}finally{
			ConnectDB.closeConnection(conn);
			System.out.println("updateImage method ends");
		}
	}


	@Override
	public void updatePhonum(String username, String num) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		String sql="update user set PhoNum =? where Username=?";
		System.out.println("updatePhoNum method begins");
		try{
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, num);
			ps.setString(2, username);
			ps.executeUpdate();
			ps.close();
		}catch(Exception e){
			
			System.out.print("Fail to updatePhoNum");
			System.out.println(e);
		}finally{
			ConnectDB.closeConnection(conn);
			System.out.println("updatePhoNum method ends");
		}
	}


	
	

}
