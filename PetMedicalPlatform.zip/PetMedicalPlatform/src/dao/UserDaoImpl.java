package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bean.Pet;
import bean.User;

public class UserDaoImpl implements UserDao{

	@Override
	public void addUser(User user) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("addUser method begins");
	    String sql="insert into user(Username,UserPwd,UserMail,PhoNum) values (?,?,?,?)";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setString(1, user.getUsername());
	    	ps.setString(2, user.getUserPwd());
	    	ps.setString(3, user.getUserMail());
	    	ps.setString(4, user.getPhoNum());
	    	int row=ps.executeUpdate();
	    	if (row>0) {
	    		System.out.println("Success to addUser");
			ps.close();	
			}
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
			System.out.println("Fail to addUser");
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
			System.out.println("addUser method ends");
		}
	}

	@Override
	public void addPet(Pet pet) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("addPet method begins");
	    String sql="insert into pet(PetName,Ownername,PetSex,PetAge,PetType) values (?,?,?,?,?)";
	    try {
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setString(1, pet.getPetName());
	    	ps.setString(2, pet.getOwnername());
	    	ps.setString(3, pet.getPetSex());
	    	ps.setDouble(4, pet.getPetAge());
	    	ps.setString(5, pet.getPetType());
	    	
	    	ps.executeUpdate();
	    	int row=ps.executeUpdate();
	    	if (row>0) {
	    		System.out.println("Success to addPet");
			ps.close();	
			}
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Fail to addPet");
		}finally {
			ConnectDB.closeConnection(conn);
			System.out.println("addPet method ends");
		}
	}

	@Override
	public boolean isUserExist(String username) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		String sql="select * from user where Username=?";
		System.out.println("isUserExist method begins");
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, username);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				return true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("error appears!!! ");
		}finally {
			ConnectDB.closeConnection(conn);   
			System.out.println("isUserExist method ends");
		}
		return false;
	}

	@Override
	public User getUserInfo(String userName, String userPwd) {
		// TODO Auto-generated method stub
		User user=null;
		Connection conn=ConnectDB.getConnection();
		String sql="select * from user where Username=? and UserPwd=? ";
		System.out.println("getUserInfo begins");
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, userName);
			ps.setString(2, userPwd);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				user=new User();
				user.setUsername(userName);
				user.setUserPwd(userPwd);
				user.setUserMail(rs.getString("UserMail"));
				user.setPhoNum(rs.getString("PhoNum"));
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Fail to getUserInfo");
		}finally {
			ConnectDB.closeConnection(conn);
			System.out.println("getUserInfo method ends");
		}
		return user;
	}

	@Override
	public ArrayList<Pet> getPetInfo(String userName) {
		// TODO Auto-generated method stub
		ArrayList<Pet> petInfo=new ArrayList<Pet>();
		Connection conn=ConnectDB.getConnection();
		String sql="select * from pet where Ownername=?";
		System.out.println("getPetInfo method begins");
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, userName);
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				String PetID=rs.getString("PetID");
				String petName=rs.getString("PetName");
				String PetSex=rs.getString("PetSex");
				double PetAge=rs.getDouble("PetAge");
				String PetType=rs.getString("PetType");
				
				Pet pet=new Pet(PetID, petName, userName, PetSex, PetAge, PetType);
				petInfo.add(pet);
				
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Fail to getPetInfo");
		}finally {
			ConnectDB.closeConnection(conn);
			System.out.println("getPetInfo method ends");
		}
		return petInfo;
	}

	@Override
	public void changePwd(String userName,String userPwd) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		String sql="update user set UserPwd =? where Username=?";
		System.out.println("changePwd method begins");
		try{
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, userPwd);
			ps.setString(2, userName);
			ps.executeUpdate();
			ps.close();
		}catch(Exception e){
			
			System.out.print("Fail to changePwd");
		}finally{
			ConnectDB.closeConnection(conn);
			System.out.println("changePwd method ends");
		}
		
	}
	

}
