package dao;

import java.util.ArrayList;
import java.util.Date;

import bean.AntiRecord;
import bean.Pet;
import bean.PetKind;

public interface PetDao {
	public void addPet(Pet pet);
	public ArrayList<Pet> getPetInfo(String userName);
	public ArrayList<PetKind> getPetKind(String type);
	public String getdays(String dedate);
	public Pet getPetDetail(int pid);
	public void modifyPet(int pid, int sex, int ancestry,int neuter);
	public ArrayList<AntiRecord> showRecord(int pid,int type);
	public void addAntiRecord(int pid,int type,Date date);
	public void delAntiRecord(int antiid);

}
