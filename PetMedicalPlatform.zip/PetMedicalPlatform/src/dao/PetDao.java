package dao;

import java.util.ArrayList;

import bean.Pet;
import bean.PetKind;

public interface PetDao {
	public void addPet(Pet pet);
	public ArrayList<Pet> getPetInfo(String userName);
	public ArrayList<PetKind> getPetKind(String type);

}
