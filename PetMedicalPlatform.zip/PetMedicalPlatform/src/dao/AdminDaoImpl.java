package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bean.Admin;
import bean.Doctor;


public class AdminDaoImpl implements AdminDao{

	@Override
	public ArrayList<Doctor> getDrList(int state) {
		// TODO Auto-generated method stub
		ArrayList<Doctor> pendinglist=new ArrayList<Doctor>();
		Connection conn = ConnectDB.getConnection();
		String sql = "select * from doctor where state = ?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, state);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				int DrID=rs.getInt("DrID");
				String DrName=rs.getString("DrName");
				String DrMail=rs.getString("DrMail");
				String DrHosptl=rs.getString("DrHosptl");
				String truename=rs.getString("truename");
				Doctor doctor=new Doctor(DrID, DrName, DrMail, DrHosptl,truename);
				pendinglist.add(doctor);
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		return pendinglist;
	}

	@Override
	public void changeDrState(int id,int state) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("changeState begins");
	    String sql="update doctor set state=? where DrID=?";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setInt(1, state);
	    	ps.setInt(2, id);
	    	
	        ps.executeUpdate();
	    	
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
	
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
		}
	}

	@Override
	public void deleteSignup(int id) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("delete method begins");
	    String sql="delete from doctor where DrID=?";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setInt(1, id);
	    	
	        ps.executeUpdate();
	    	
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
	
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
		}
	}

	@Override
	public void deleteArticle(int aid) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("delete method begins");
	    String sql="update article set state=3 where ArticleId=?";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setInt(1, aid);
	    	
	        ps.executeUpdate();
	    	
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
	
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
		}

	}

	@Override
	public Admin getAdminInfo(String name, String pwd) {
		// TODO Auto-generated method stub
		Admin admin=null;
		Connection conn=ConnectDB.getConnection();
		String sql="select * from admin where Adname=? and Adpwd=?";
		System.out.println("getAdInfo begins");
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, name);
			ps.setString(2, pwd);
			System.out.println(sql);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
                admin=new Admin();
                admin.setAdname(name);
                admin.setAdpwd(pwd);
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Fail to getAdInfo");
		}finally {
			ConnectDB.closeConnection(conn);
			System.out.println("getAdInfo method ends");
		}
		return admin;
	}

	@Override
	public ArrayList<String> getUserList(int state) {
		// TODO Auto-generated method stub
		ArrayList<String> pendinglist=new ArrayList<String>();
		Connection conn = ConnectDB.getConnection();
		String sql = "select * from user where state = ?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, state);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				String username=rs.getString("Username");
				pendinglist.add(username);
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		return pendinglist;
	}

	@Override
	public void changeUserState(String username, int state) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("changeState begins");
	    String sql="update user set activated=? where Username=?";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setInt(1, state);
	    	ps.setString(2, username);
	    	
	        ps.executeUpdate();
	    	
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
	
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
		}
	}


}
