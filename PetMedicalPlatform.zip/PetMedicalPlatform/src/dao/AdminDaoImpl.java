package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import bean.Admin;
import bean.Answer;
import bean.Doctor;


public class AdminDaoImpl implements AdminDao{

	@Override
	public ArrayList<Doctor> getDrList(int state) {
		// TODO Auto-generated method stub
		ArrayList<Doctor> pendinglist=new ArrayList<Doctor>();
		Connection conn = ConnectDB.getConnection();
		String sql = "select * from doctor where state = ?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, state);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				int DrID=rs.getInt("DrID");
				String DrName=rs.getString("DrName");
				String DrMail=rs.getString("DrMail");
				String DrHosptl=rs.getString("DrHosptl");
				String truename=rs.getString("truename");
				Doctor doctor=new Doctor(DrID, DrName, DrMail, DrHosptl,truename);
				pendinglist.add(doctor);
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		return pendinglist;
	}

	@Override
	public void changeDrState(int id,int state) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("changeState begins");
	    String sql="update doctor set state=? where DrID=?";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setInt(1, state);
	    	ps.setInt(2, id);
	    	
	        ps.executeUpdate();
	    	
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
	
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
		}
	}

	@Override
	public void deleteSignup(int id) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("delete method begins");
	    String sql="delete from doctor where DrID=?";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setInt(1, id);
	    	
	        ps.executeUpdate();
	    	
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
	
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
		}
	}

	@Override
	public void deleteArticle(int aid) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("delete method begins");
	    String sql="update article set state=3 where ArticleId=?";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setInt(1, aid);
	    	
	        ps.executeUpdate();
	    	
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
	
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
		}

	}

	@Override
	public Admin getAdminInfo(String name, String pwd) {
		// TODO Auto-generated method stub
		Admin admin=null;
		Connection conn=ConnectDB.getConnection();
		String sql="select * from admin where Adname=? and Adpwd=?";
		System.out.println("getAdInfo begins");
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, name);
			ps.setString(2, pwd);
			System.out.println(sql);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
                admin=new Admin();
                admin.setAdname(name);
                admin.setAdpwd(pwd);
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Fail to getAdInfo");
		}finally {
			ConnectDB.closeConnection(conn);
			System.out.println("getAdInfo method ends");
		}
		return admin;
	}

	@Override
	public ArrayList<String> getUserList(int state) {
		// TODO Auto-generated method stub
		ArrayList<String> pendinglist=new ArrayList<String>();
		Connection conn = ConnectDB.getConnection();
		String sql = "select * from user where activated = ?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, state);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				String username=rs.getString("Username");
				pendinglist.add(username);
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		return pendinglist;
	}

	@Override
	public void changeUserState(String username, int state) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("changeState begins");
	    String sql="update user set activated=? where Username=?";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setInt(1, state);
	    	ps.setString(2, username);
	    	
	        ps.executeUpdate();
	    	
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
	
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
		}
	}

	@Override
	public void lockAnswer(int Taid, int TrId) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("lockAnswer begins");
	    String sql="update transwer set state=1 where Taid=?";
	    String sql1="update trquestion set state=0 where TrId=?";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	PreparedStatement ps1=conn.prepareStatement(sql1);
	    	ps.setInt(1, Taid);
	    	ps1.setInt(1, TrId);
	        ps.executeUpdate();
	        ps1.executeUpdate();	    					
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
	
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
		}
	}

	@Override
	public ArrayList<Answer> getAnswerList() {
		// TODO Auto-generated method stub
		Connection conn = ConnectDB.getConnection();
		ArrayList<Answer> answers=new ArrayList<Answer>();
		String sql = "SELECT * FROM transwer INNER JOIN trquestion ON transwer.Trid=trquestion.TrId AND transwer.state=0 ORDER BY transwer.date DESC";
		Answer answer=new Answer();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
					int Trid=rs.getInt("TrId");
					int Taid=rs.getInt("Taid");
					String username=rs.getString("Username");
					int pid=rs.getInt("petId");
					int did=rs.getInt("did");
					String drName=rs.getString("drName");
					String content=rs.getString("Tacontent");
					Date date=rs.getDate("date");					
					answer=new Answer(Taid, Trid, username, did, drName, pid, content, date);
					answers.add(answer);
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		
//		Iterator<Article> iterator=myArticles.iterator();
//		Article article1=new Article();
//		while(iterator.hasNext()){
//			article1=iterator.next();
//			System.out.println(article1.getAid());
//		}
//		
//		System.out.println("size:"+myArticles.size());
		return answers;
	}


}
