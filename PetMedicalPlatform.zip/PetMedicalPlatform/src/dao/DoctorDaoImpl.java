package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
//import java.util.Iterator;
import bean.Article;
import bean.Doctor;
import bean.Query;



public class DoctorDaoImpl implements DoctorDao {

	@Override
	public void addDoctor(Doctor doctor) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("addDr method begins");
	    String sql="insert into doctor(Drname,DrPwd,DrPho,DrMail,DrIntro,DrGoodAt,DrHosptl,truename) values (?,?,?,?,?,?,?,?)";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setString(1, doctor.getDrName());
	    	ps.setString(2, doctor.getDrPwd());
	    	ps.setString(3, doctor.getDrPho());
	    	ps.setString(4, doctor.getDrMail());
	    	ps.setString(5, doctor.getDrIntro());
	    	ps.setString(6, doctor.getDrGoodAt());
	    	ps.setString(7, doctor.getDrHosptl());
	    	ps.setString(8, doctor.getTruename());
	    	int row=ps.executeUpdate();
	    	if (row>0) {
	    		System.out.println("Success to addDr");
			ps.close();	
			}
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
			System.out.println("Fail to addDr");
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
			System.out.println("addDr method ends");
		}		
		
	}

	@Override
	public Doctor findDrByName(String name) {
		// TODO Auto-generated method stub
		Connection conn = ConnectDB.getConnection();
		String sql = "select * from doctor where DrName = ? and state=1";
		Doctor doctor=new Doctor();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, name);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				doctor.setDrName(rs.getString("DrName"));
				doctor.setDrPwd(rs.getString("DrPwd"));
				doctor.setDrMail(rs.getString("DrMail"));
				doctor.setTruename(rs.getString("truename"));
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		return doctor;
	}

	@Override
	public void changepwd(String username, String pwd) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		String sql="update doctor set DrPwd =? where DrName=?";
		System.out.println("changePwd method begins");
		try{
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, pwd);
			ps.setString(2, username);
			ps.executeUpdate();
			ps.close();
		}catch(Exception e){
			
			System.out.print("Fail to changePwd");
		}finally{
			ConnectDB.closeConnection(conn);
			System.out.println("changePwd method ends");
		}
	}

	@Override
	public Doctor getDoctorInfo(String username) {
		// TODO Auto-generated method stub
		Doctor doctor=null;
		Connection conn=ConnectDB.getConnection();
		String sql="select * from doctor where DrName=?";
		System.out.println("getDrInfo begins");
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, username);
			System.out.println(sql);
			System.out.println("sql:"+username);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				doctor=new Doctor();
				doctor.setDrID(rs.getInt("DrID"));
				doctor.setDrName(username);
				doctor.setDrPwd(rs.getString("DrPwd"));
				doctor.setDrPho(rs.getString("DrPho"));
				doctor.setDrMail(rs.getString("DrMail"));
				doctor.setDrHosptl(rs.getString("DrHosptl"));
				doctor.setDrGoodAt(rs.getString("DrGoodAt"));
				doctor.setDrIntro(rs.getString("DrIntro"));
				doctor.setTruename(rs.getString("truename"));
				doctor.setImage(rs.getString("image"));

			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Fail to getDrInfo");
		}finally {
			ConnectDB.closeConnection(conn);
			System.out.println("getDrInfo method ends");
		}
		return doctor;
	}

//	@Override
//	public ArrayList<Doctor> getPendingRegisterList() {
//		// TODO Auto-generated method stub
//		ArrayList<Doctor> pendinglist=new ArrayList<Doctor>();
//		Connection conn = ConnectDB.getConnection();
//		String sql = "select * from doctor where state = 0";
//		try {
//			PreparedStatement ps = conn.prepareStatement(sql);
//			ResultSet rs = ps.executeQuery();
//			while(rs.next()){
//				int DrID=rs.getInt("DrID");
//				String DrName=rs.getString("DrName");
//				String DrMail=rs.getString("DrMail");
//				String DrHosptl=rs.getString("DrHosptl");
//				Doctor doctor=new Doctor(DrID, DrName, DrMail, DrHosptl);
//				pendinglist.add(doctor);
//			}
//			rs.close();
//			ps.close();
//	
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}finally{
//			ConnectDB.closeConnection(conn);
//		}
//		return pendinglist;
//	}

//	@Override
//	public void changeState(int id) {
//		// TODO Auto-generated method stub
//		Connection conn=ConnectDB.getConnection();
//		System.out.println("changeState begins");
//	    String sql="update doctor set state=? where DrID=?";
//	    try {
//	    	conn.setAutoCommit(false);
//	    	PreparedStatement ps=conn.prepareStatement(sql);
//	    	ps.setBoolean(1, true);
//	    	ps.setInt(2, id);
//	    	
//	        ps.executeUpdate();
//	    	
//	    	
//			
//		} catch (Exception e) {
//			// TODO: handle exception
//			if (conn!=null) {
//				try {
//					conn.rollback();
//				} catch (SQLException e2) {
//					// TODO: handle exception
//					e2.printStackTrace();
//				}
//			}
//			System.out.println(e.getMessage());
//	
//		}finally {
//			
//			if (conn!=null) {
//				try {
//					conn.setAutoCommit(true);
//					conn.close();
//				} catch (SQLException e3) {
//					// TODO: handle exception
//					e3.printStackTrace();
//				}
//			}
//		}
//	}

//	@Override
//	public void deleteSignup(int id) {
//		// TODO Auto-generated method stub
//		Connection conn=ConnectDB.getConnection();
//		System.out.println("delete method begins");
//	    String sql="delete from doctor where DrID=?";
//	    try {
//	    	conn.setAutoCommit(false);
//	    	PreparedStatement ps=conn.prepareStatement(sql);
//	    	ps.setInt(1, id);
//	    	
//	        ps.executeUpdate();
//	    	
//	    	
//			
//		} catch (Exception e) {
//			// TODO: handle exception
//			if (conn!=null) {
//				try {
//					conn.rollback();
//				} catch (SQLException e2) {
//					// TODO: handle exception
//					e2.printStackTrace();
//				}
//			}
//			System.out.println(e.getMessage());
//	
//		}finally {
//			
//			if (conn!=null) {
//				try {
//					conn.setAutoCommit(true);
//					conn.close();
//				} catch (SQLException e3) {
//					// TODO: handle exception
//					e3.printStackTrace();
//				}
//			}
//		}
//	}

	@Override
	public void writeArticle(Article article) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		java.util.Date  date=new java.util.Date();
		java.sql.Date  date1=new java.sql.Date(date.getTime());
		System.out.println(" writeArticle method begins");
	    String sql="insert into article(title,tag1,tag2,date,DrId,Drname,content) values (?,?,?,?,?,?,?)";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setString(1, article.getTitle());
	    	ps.setString(2, article.getTag1());
	    	ps.setString(3, article.getTag2());
	    	ps.setDate(4, date1);
	    	ps.setInt(5, article.getDid());
	    	ps.setString(6, article.getDname());
	    	ps.setString(7, article.getContent());
	    	int row=ps.executeUpdate();
	    	if (row>0) {
	    		System.out.println("Success to writeArticle");
			ps.close();	
			}
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
			System.out.println("Fail to writeArticle");
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
			System.out.println("writeArticle method ends");
		}		


	}

	@Override
	public ArrayList<Article> getMyArticles(int did) {
		// TODO Auto-generated method stub
		Connection conn = ConnectDB.getConnection();
		ArrayList<Article> myArticles=new ArrayList<Article >();
		String sql = "select * from article where DrId = ? and state=0";
		Article article=new Article(); 
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1,did);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				int aid=rs.getInt("ArticleId");;
				String title=rs.getString("title");
				String tag1=rs.getString("tag1");
				String tag2=rs.getString("tag2");
				String content=rs.getString("content");
				Date date=rs.getDate("date");
				String Drname=rs.getString("Drname");
				int state=rs.getInt("state");
				article=new Article(aid, did, title, tag1, tag2, content, Drname, state, date);
			    myArticles.add(article);	
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		
//		Iterator<Article> iterator=myArticles.iterator();
//		Article article1=new Article();
//		while(iterator.hasNext()){
//			article1=iterator.next();
//			System.out.println(article1.getAid());
//		}
//		
//		System.out.println("size:"+myArticles.size());
		return myArticles;
	}

	@Override
	public Article getArticleDetail(int aid) {
		// TODO Auto-generated method stub
		Article article=new Article();
		Connection conn = ConnectDB.getConnection();
		String sql = "select * from article where ArticleId = ?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1,aid);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				int did=rs.getInt("DrId");;
				String title=rs.getString("title");
				String tag1=rs.getString("tag1");
				String tag2=rs.getString("tag2");
				String content=rs.getString("content");
				Date date=rs.getDate("date");
				String Drname=rs.getString("Drname");
				int state=rs.getInt("state");
				article=new Article(aid, did, title, tag1, tag2, content, Drname, state, date);	
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		return article;
	}

	@Override
	public void updateArticle(Article article) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		java.util.Date  date=new java.util.Date();
		java.sql.Date  date1=new java.sql.Date(date.getTime());
		System.out.println("updateArticle method begins");
		String sql0="update article set state=1 where ArticleId="+article.getAid();
	    String sql="update article set title=?,tag1=?,tag2=?,date=?,content=? where ArticleId=?";
	    String sql2="update article set state=0 where ArticleId="+article.getAid();
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps0=conn.prepareStatement(sql0);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	PreparedStatement ps2=conn.prepareStatement(sql2);
	    	ps0.executeUpdate();
	    	ps.setString(1, article.getTitle());
	    	ps.setString(2, article.getTag1());
	    	ps.setString(3, article.getTag2());
	    	ps.setDate(4, date1);
	    	ps.setString(5, article.getContent());
	    	ps.setInt(6, article.getAid());
	    	int row=ps.executeUpdate();
	    	if (row>0) {
	    		System.out.println("Success to updateArticle");
	    		ps2.executeUpdate();
			}
	    	
	    	ps0.close();
			ps.close();	
			ps2.close();
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
			System.out.println("Fail to updateArticle");
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
			System.out.println("updateArticle method ends");
		}		

	}

	@Override
	public ArrayList<Query> getQueryList() {
		// TODO Auto-generated method stub
		Connection conn = ConnectDB.getConnection();
		ArrayList<Query> queries=new ArrayList<Query>();
		String sql = "select * from trquestion where state=0";
		Query query=new Query();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				int qid=rs.getInt("TrId");
				String Username=rs.getString("Username");
				int pid=rs.getInt("pid");
                int type=rs.getInt("Trtype");
                int subtype=rs.getInt("TrSubtype");
                String title=rs.getString("TrTitle");
                String content=rs.getString("TrContent");
                Date date=rs.getDate("date");
                int state=rs.getInt("state");
				query=new Query(qid, Username, pid, type, subtype, title, content, date,state);
				queries.add(query);	
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		return queries;
	}

	@Override
	public Query getQueryDetail(int qid) {
		// TODO Auto-generated method stub
		Connection conn = ConnectDB.getConnection();
		String sql = "select * from trquestion where TrId=?";
		System.out.println("GetQueryDetail Method begin");
		Query query=new Query();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, qid);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				query.setContent(rs.getString("TrContent"));
				query.setDate(rs.getDate("date"));
				query.setSubtype(rs.getInt("TrSubtype"));
				query.setTitle(rs.getString("TrTitle"));
				query.setType(rs.getInt("Trtype"));
				query.setUsername(rs.getString("Username"));
				query.setPid(rs.getInt("pid"));
				query.setTrId(rs.getInt("TrId"));
				query.setState(rs.getInt("state"));
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		return query;
	}

	@Override
	public void updateQueryState(int qid,int state) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("changeState begins");
	    String sql="update trquestion set state=? where TrId=?";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setInt(1, state);
	    	ps.setInt(2, qid);
	    	
	        ps.executeUpdate();
	    	
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
	
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
		}
		
	}

	@Override
	public void answerQuery(int Trid, String username, int did,String DrName, int petId, String tacontent) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		java.util.Date  date=new java.util.Date();
		java.sql.Date  date1=new java.sql.Date(date.getTime());
		System.out.println(" answerQuery method begins");
	    String sql="insert into transwer(Trid,Username,did,petId,tacontent,date,state,drName) values (?,?,?,?,?,?,?,?)";
	    String sql2="update trquestion set state=2 where TrId=?";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	PreparedStatement ps2=conn.prepareStatement(sql2);
	    	ps.setInt(1, Trid);
	    	ps.setString(2, username);
	    	ps.setInt(3, did);
	    	ps.setInt(4, petId);
	    	ps.setString(5, tacontent);
	    	ps.setDate(6, date1);
	    	ps.setInt(7, 0);
	    	ps.setString(8, DrName);
	    	ps2.setInt(1, Trid);
	    	int row=ps.executeUpdate();
	    	int row1=ps2.executeUpdate();
	    	if (row>0&&row1>0) {
	    		System.out.println("Success to answerQuery");
			ps.close();	
			ps2.close();
			}
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
					System.out.println("changeState begins");
				    String sql3="update trquestion set state=? where TrId=?";
				    try {
				    	conn.setAutoCommit(false);
				    	PreparedStatement ps=conn.prepareStatement(sql3);
				    	ps.setInt(1, 0);
				    	ps.setInt(2, Trid);
				    	
				        ps.executeUpdate();
				    	
				    	
						
					} catch (Exception e1) {
						// TODO: handle exception
						if (conn!=null) {
							try {
								conn.rollback();
							} catch (SQLException e2) {
								// TODO: handle exception
								e2.printStackTrace();
							}
						}
						System.out.println(e1.getMessage());
				
					}
					
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			
			System.out.println(e.getMessage());
			System.out.println("Fail to answerQuery");
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
			System.out.println("answerQuery method ends");
		}		

		
	}

	@Override
	public ArrayList<Query> getAnswerQueryList(int did) {
		// TODO Auto-generated method stub
		Connection conn = ConnectDB.getConnection();
		ArrayList<Query> queries=new ArrayList<Query>();
		String sql = "SELECT * from (trquestion JOIN transwer on transwer.Trid=trquestion.TrId) WHERE transwer.did=? "+" ORDER BY transwer.date DESC";
		Query query=new Query(); 
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1,did);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				
					int Trid=rs.getInt("TrId");
					int pid=rs.getInt("pid");
					int Trtype=rs.getInt("Trtype");
					int TrSubtype=rs.getInt("TrSubtype");
					String title=rs.getString("TrTitle");
					String content=rs.getString("TrContent");
					Date date=rs.getDate("date");
					int state=rs.getInt("state");
					String username=rs.getString("Username");
					query=new Query(Trid, username, pid, Trtype, TrSubtype, title, content, date,state);
					queries.add(query);	
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		
//		Iterator<Article> iterator=myArticles.iterator();
//		Article article1=new Article();
//		while(iterator.hasNext()){
//			article1=iterator.next();
//			System.out.println(article1.getAid());
//		}
//		
//		System.out.println("size:"+myArticles.size());
		return queries;
	}

	@Override
	public boolean ifDrExist(String username) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		String sql="select * from doctor where DrName=?";
		System.out.println("ifDrExist method begins");
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, username);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				return true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("error appears!!! ");
		}finally {
			ConnectDB.closeConnection(conn);   
			System.out.println("ifDrExist method ends");
		}
		return false;
	}

	@Override
	public String getImage(String username) {
		// TODO Auto-generated method stub
	    String path=null;
		Connection conn=ConnectDB.getConnection();
		String sql="select * from doctor where DrName=?";
		System.out.println("getImagePath method begins");
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, username);
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				//int PetID=rs.getInt("PetID");
                 path=rs.getString("image");   
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Fail to getImagePath");
		}finally {
			ConnectDB.closeConnection(conn);
			System.out.println("getImagePath method ends");
		}
	    return path;
	}

	@Override
	public void addImage(String username, String path) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("addImage method begins");
	    String sql="update doctor set image =? where DrName=?";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setString(1, path);
	    	ps.setString(2, username);
	    	int row=ps.executeUpdate();
	    	if (row>0) {
	    		System.out.println("Success to addImage");
			ps.close();	
			}
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println("Fail to addImage");
		}finally {
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
			ConnectDB.closeConnection(conn);
			System.out.println("addImage method ends");
		}
	}

	@Override
	public void modifyInfo(int did, String phone, String hospital, String goodat, String intro) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		String sql="update doctor set DrPho =?, DrHosptl=?, DrGoodAt=?, DrIntro=? where DrID=?";
		System.out.println("updateInfo method begins");
		try{
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, phone);
			ps.setString(2, hospital);
			ps.setString(3, goodat);
			ps.setString(4, intro);
			ps.setInt(5, did);
			ps.executeUpdate();
			ps.close();
		}catch(Exception e){
			
			System.out.print("Fail to updateInfo");
			System.out.println(e);
		}finally{
			ConnectDB.closeConnection(conn);
			System.out.println("updateInfo method ends");
		}
	}

	@Override
	public ArrayList<Doctor> getAllDrInfo() {
		// TODO Auto-generated method stub
		Connection conn = ConnectDB.getConnection();
		ArrayList<Doctor> doctors=new ArrayList<Doctor>();
		String sql = "select * from doctor where state=1";
		Doctor doctor=new Doctor();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				int did=rs.getInt("DrID");
				String DrName=rs.getString("DrName");
				String DrPho=rs.getString("DrPho");
				String pwd=rs.getString("DrPwd");
				String DrMail=rs.getString("DrMail");
				String intro=rs.getString("DrIntro");
				String goodat=rs.getString("DrGoodAt");
				String hosptl=rs.getString("DrHosptl");
				String image=rs.getString("image");
				String truename=rs.getString("truename");
				doctor=new Doctor(did, DrName, pwd, DrPho, DrMail, hosptl, goodat, intro, truename,image);
				doctors.add(doctor);

			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		return doctors;
	}

}
