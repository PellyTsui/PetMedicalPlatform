package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bean.Doctor;



public class DoctorDaoImpl implements DoctorDao {

	@Override
	public void addDoctor(Doctor doctor) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("addDr method begins");
	    String sql="insert into doctor(Drname,DrPwd,DrPho,DrMail,DrIntro,DrGoodAt,DrHosptl,locate) values (?,?,?,?,?,?,?,?)";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setString(1, doctor.getDrName());
	    	ps.setString(2, doctor.getDrPwd());
	    	ps.setString(3, doctor.getDrPho());
	    	ps.setString(4, doctor.getDrMail());
	    	ps.setString(5, doctor.getDrIntro());
	    	ps.setString(6, doctor.getDrGoodAt());
	    	ps.setString(7, doctor.getDrHosptl());
	    	ps.setInt(8, doctor.getLocate());
	    	int row=ps.executeUpdate();
	    	if (row>0) {
	    		System.out.println("Success to addDr");
			ps.close();	
			}
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
			System.out.println("Fail to addDr");
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
			System.out.println("addDr method ends");
		}		
		
	}

	@Override
	public Doctor findDrByName(String name) {
		// TODO Auto-generated method stub
		Connection conn = ConnectDB.getConnection();
		String sql = "select * from doctor where DrName = ?";
		Doctor doctor=new Doctor();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, name);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				doctor.setDrName(name);
				doctor.setDrMail(rs.getString("DrMail"));
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		return doctor;
	}

	@Override
	public void changepwd(String username, String pwd) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		String sql="update doctor set DrPwd =? where DrName=?";
		System.out.println("changePwd method begins");
		try{
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, pwd);
			ps.setString(2, username);
			ps.executeUpdate();
			ps.close();
		}catch(Exception e){
			
			System.out.print("Fail to changePwd");
		}finally{
			ConnectDB.closeConnection(conn);
			System.out.println("changePwd method ends");
		}
	}

	@Override
	public Doctor getDoctorInfo(String username, String pwd) {
		// TODO Auto-generated method stub
		Doctor doctor=null;
		Connection conn=ConnectDB.getConnection();
		String sql="select * from doctor where DrName=? and DrPwd=? and state=1";
		System.out.println("getDrInfo begins");
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, pwd);
			System.out.println(sql);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				doctor=new Doctor();
				doctor.setDrName(username);
				doctor.setDrPwd(pwd);
				doctor.setDrPho(rs.getString("DrPho"));
				doctor.setDrMail(rs.getString("DrMail"));
				doctor.setDrHosptl(rs.getString("DrHosptl"));
				doctor.setLocate(rs.getInt("locate"));
				doctor.setDrGoodAt(rs.getString("DrGoodAt"));
				doctor.setDrIntro(rs.getString("DrIntro"));

			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Fail to getDrInfo");
		}finally {
			ConnectDB.closeConnection(conn);
			System.out.println("getDrInfo method ends");
		}
		return doctor;
	}

	@Override
	public ArrayList<Doctor> getPendingRegisterList() {
		// TODO Auto-generated method stub
		ArrayList<Doctor> pendinglist=new ArrayList<Doctor>();
		Connection conn = ConnectDB.getConnection();
		String sql = "select * from doctor where state = 0";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				int DrID=rs.getInt("DrID");
				String DrName=rs.getString("DrName");
				String DrMail=rs.getString("DrMail");
				String DrHosptl=rs.getString("DrHosptl");
				Doctor doctor=new Doctor(DrID, DrName, DrMail, DrHosptl);
				pendinglist.add(doctor);
			}
			rs.close();
			ps.close();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectDB.closeConnection(conn);
		}
		return pendinglist;
	}

	@Override
	public void changeState(int id) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("changeState begins");
	    String sql="update doctor set state=? where DrID=?";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setBoolean(1, true);
	    	ps.setInt(2, id);
	    	
	        ps.executeUpdate();
	    	
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
	
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
		}
	}

	@Override
	public void deleteSignup(int id) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("delete method begins");
	    String sql="delete from doctor where DrID=?";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setInt(1, id);
	    	
	        ps.executeUpdate();
	    	
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
	
		}finally {
			
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
		}
	}

}
