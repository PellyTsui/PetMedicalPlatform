package dao;

import java.sql.*;

public class ConnectDB {
private static Connection con=null;
	
	public static Connection getConnection(){
		String username="root";
		String password="tezukafuji";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("��������");
			String url = "jdbc:mysql://localhost:3306/pet_health_care";
			con = DriverManager.getConnection(url, username, password);
			System.out.println("ȡ������");
		} catch (Exception e) {
			System.out.println("����ʧ��");
			e.printStackTrace();
		}
		return con;
	}

	public static void closeConnection(Connection conn){
		if(conn != null){
			try {
				conn.close();	
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	

}
