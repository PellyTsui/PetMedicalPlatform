package dao;

import java.util.ArrayList;

import bean.Admin;
import bean.Doctor;

public interface AdminDao {
	   public ArrayList<Doctor> getPendingRegisterList();
	   public void changeState(int id);
	   public void deleteSignup(int id);
	   
	   public void deleteArticle(int aid);
	   
	   public Admin getAdminInfo(String name,String pwd);
	

}
