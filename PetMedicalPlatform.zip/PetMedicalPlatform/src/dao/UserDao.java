package dao;

import java.util.ArrayList;

import bean.Article;
import bean.User;


public interface UserDao {
	
	//basic function
	public void addUser(User user);
	public boolean isUserExist(String username);
	public User getUserInfo(String userName,String userPwd);
	public void changePwd(String userName,String userPwd);
	
	User findUserById(int userId);
	User findUserByName(String userName);  
    User findUserByNameOrEmail(String nameOrEmail);
    public void updateUserRandomCode(int userId, String randomCode);
    
    public boolean isEmailExist(String mail);
    public void updateUserActivate(int userId);
    
    public ArrayList<Article> getAllArticles();
    public ArrayList<Article> selectArticlesTag1(String tag1);
    public ArrayList<Article> selectArticlesTag2(String tag2);
    public ArrayList<Article> selectArticleTag12(String tag1,String tag2);
    

}
