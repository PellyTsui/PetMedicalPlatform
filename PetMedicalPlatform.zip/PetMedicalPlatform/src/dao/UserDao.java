package dao;

import bean.User;


public interface UserDao {
	
	//basic function
	public void addUser(User user);
	public boolean isUserExist(String username);
	public User getUserInfo(String userName,String userPwd);
	public void changePwd(String userName,String userPwd);
	
	User findUserById(int userId);
	User findUserByName(String userName);  
    User findUserByNameOrEmail(String nameOrEmail);
    public void updateUserRandomCode(int userId, String randomCode);
    
    public boolean isEmailExist(String mail);
    public void updateUserActivate(int userId);
    

}
