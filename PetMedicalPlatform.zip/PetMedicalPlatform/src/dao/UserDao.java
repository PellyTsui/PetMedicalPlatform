package dao;

import java.util.ArrayList;

import bean.Pet;
import bean.User;

public interface UserDao {
	
	//basic function
	public void addUser(User user);
	public void addPet(Pet pet);
	public boolean isUserExist(String username);
	public User getUserInfo(String userName,String userPwd);
	public ArrayList<Pet> getPetInfo(String userName);
	public void changePwd(String userName,String userPwd);
	
	User findUserById(int userId);
	User findUserByName(String userName);  
    User findUserByNameOrEmail(String nameOrEmail);
    public void updateUserRandomCode(int userId, String randomCode);
    
    public boolean isEmailExist(String mail);
    public void updateUserActivate(int userId);

}
