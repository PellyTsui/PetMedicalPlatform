package dao;

import java.util.ArrayList;

import bean.Pet;
import bean.User;

public interface UserDao {
	
	//basic function
	public void addUser(User user);
	public void addPet(Pet pet);
	public boolean isUserExist(String username);
	public User getUserInfo(String userName,String userPwd);
	public ArrayList<Pet> getPetInfo(String userName);
	public void changePwd(String userName,String userPwd);
	

}
