package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;

import bean.Pet;
import bean.PetKind;

public class PetDaoImpl implements PetDao {
	
	@Override
	public void addPet(Pet pet) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("addPet method begins");
	    String sql="insert into pet(PetName,Ownername,PetSex,PetBirth,PetType,PetKind,ancestry,neuter) values (?,?,?,?,?,?,?,?)";
	    java.util.Date birthdate=pet.getBirthdate();
	    Date PetBirth=new Date(birthdate.getTime());

	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setString(1, pet.getPetName());
	    	ps.setString(2, pet.getOwnername());
	    	ps.setInt(3, Integer.parseInt(pet.getPetSex()));
	    	ps.setDate(4, PetBirth);
	    	ps.setString(5, pet.getPetType());
	    	ps.setString(6, pet.getPetKind());
	    	ps.setInt(7, Integer.parseInt(pet.getAncestry()));
	    	ps.setInt(8, Integer.parseInt(pet.getNeuter()));
	    	int row=ps.executeUpdate();
	    	if (row>0) {
	    		System.out.println("Success to addPet");
			ps.close();	
			}
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println("Fail to addPet");
		}finally {
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
			ConnectDB.closeConnection(conn);
			System.out.println("addPet method ends");
		}
	}

	@Override
	public ArrayList<Pet> getPetInfo(String userName) {
		// TODO Auto-generated method stub
		ArrayList<Pet> petInfo=new ArrayList<Pet>();
		Connection conn=ConnectDB.getConnection();
		String sql="select * from pet where Ownername=?";
		System.out.println("getPetInfo method begins");
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, userName);
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				int PetID=rs.getInt("PetID");
				String petName=rs.getString("PetName");
				int PetSex=rs.getInt("PetSex");
				java.util.Date birthdate=rs.getDate("PetBirth");				
				String PetType=rs.getString("PetType");
				String PetKind=rs.getString("PetKind");
				int ancestry=rs.getInt("ancestry");
				int neuter=rs.getInt("neuter");
				
				String petSex="����֪����";
				if (PetSex==1) {
					petSex="�к�";
				}
				else if (PetSex==0) {
					petSex="Ů��";
				}
				
				String Ancestry="��֪����";
				if (ancestry==1) {
					Ancestry="��Ѫ";
				}
				else if (ancestry==0) {
					Ancestry="����";
				}
				
				String Neuter="δ����";
				if (neuter==1) {
					Neuter="�Ѿ���";
				}

				Pet pet=new Pet(PetID, petName, userName, petSex, PetType, PetKind, birthdate, Ancestry, Neuter);
				petInfo.add(pet);
				
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Fail to getPetInfo");
		}finally {
			ConnectDB.closeConnection(conn);
			System.out.println("getPetInfo method ends");
		}
		return petInfo;
	}

	@Override
	public ArrayList<PetKind> getPetKind(String type) {
		// TODO Auto-generated method stub
		ArrayList<PetKind> petKinds=new ArrayList<PetKind>();
		String sql=null;
		System.out.println("type"==type);
		Connection conn=ConnectDB.getConnection();
		if (type.equals("0")) {
			 sql="select * from dog ";
			
		}
		else if (type.equals("1")) {
			sql="select * from cat ";
		}
		System.out.println("getPetKind method begins");
		 System.out.println(sql);
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				int PetKindID=rs.getInt("PetKindId");
				String petKindName=rs.getString("PetKindName");
				PetKind petKind=new PetKind(PetKindID, petKindName);
				petKinds.add(petKind);
				
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}finally {
			ConnectDB.closeConnection(conn);
			System.out.println("getPetKind method ends");
		}
		return petKinds;
	}

	@Override
	public String getdays(String dedate) {
		// TODO Auto-generated method stub
		Calendar c = Calendar.getInstance();
		int year = c.get(Calendar.YEAR); 
		int month = c.get(Calendar.MONTH)+1; 
		int date = c.get(Calendar.DATE); 
		System.out.println("ԭ������---��"+dedate);
		String b = dedate.replace("-", "");
		System.out.println("ȥ�����ߺ�����---��"+b);
		
			System.out.println("8");
			String ryear = b.substring(0, 4);
			System.out.println("year--->"+ryear);
			String rmon = b.substring(4, 6);
			String rdate = b.substring(6, 8);
			System.out.println( (( year - (Integer.parseInt(ryear))) * 365 )  + (( month - Integer.parseInt(rmon))*30) + ( date -Integer.parseInt(rdate) ) + "");
			return ( (( year - (Integer.parseInt(ryear))) * 365 )  + (( month - Integer.parseInt(rmon))*30) + ( date -Integer.parseInt(rdate) ) + "");
	}

	@Override
	public Pet getPetDetail(int pid) {
		// TODO Auto-generated method stub
	    Pet pet=null;
		Connection conn=ConnectDB.getConnection();
		String sql="select * from pet where petID=?";
		System.out.println("getPetInfo method begins");
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setInt(1, pid);
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				//int PetID=rs.getInt("PetID");
				pet=new Pet();
				pet.setPetId(pid);
				pet.setBirthdate(rs.getDate("PetBirth"));
				pet.setPetName(rs.getString("PetName"));
			    pet.setPetKind(rs.getString("PetKind"));
			    pet.setOwnername(rs.getString("Ownername"));
				pet.setPetType(rs.getString("PetType"));
				
				int PetSex=rs.getInt("PetSex");				
				int ancestry=rs.getInt("ancestry");
				int neuter=rs.getInt("neuter");
				
				pet.setPetSex("2");
				if (PetSex==1) {
					pet.setPetSex("1");
				}
				else if (PetSex==0) {
					pet.setPetSex("0");
				}
				
				pet.setAncestry("2");
				if (ancestry==1) {
					pet.setAncestry("1");
				}
				else if (ancestry==0) {
					pet.setAncestry("0");
				}
				
				pet.setNeuter("0");
				if (neuter==1) {
					pet.setNeuter("1");
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Fail to getPetInfo");
		}finally {
			ConnectDB.closeConnection(conn);
			System.out.println("getPetInfo method ends");
		}
	    return pet;
	}

    
}
