package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bean.Pet;
import bean.PetKind;

public class PetDaoImpl implements PetDao {
	
	@Override
	public void addPet(Pet pet) {
		// TODO Auto-generated method stub
		Connection conn=ConnectDB.getConnection();
		System.out.println("addPet method begins");
	    String sql="insert into pet(PetName,Ownername,PetSex,PetAge,PetType,PetKind) values (?,?,?,?,?,?)";
	    try {
	    	conn.setAutoCommit(false);
	    	PreparedStatement ps=conn.prepareStatement(sql);
	    	ps.setString(1, pet.getPetName());
	    	ps.setString(2, pet.getOwnername());
	    	ps.setString(3, pet.getPetSex());
	    	ps.setDouble(4, pet.getPetAge());
	    	ps.setString(5, pet.getPetType());
	    	ps.setString(6, pet.getPetKind());	    	
	    	ps.executeUpdate();
	    	int row=ps.executeUpdate();
	    	if (row>0) {
	    		System.out.println("Success to addPet");
			ps.close();	
			}
	    	
			
		} catch (Exception e) {
			// TODO: handle exception
			if (conn!=null) {
				try {
					conn.rollback();
				} catch (SQLException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
			System.out.println("Fail to addPet");
		}finally {
			if (conn!=null) {
				try {
					conn.setAutoCommit(true);
					conn.close();
				} catch (SQLException e3) {
					// TODO: handle exception
					e3.printStackTrace();
				}
			}
			ConnectDB.closeConnection(conn);
			System.out.println("addPet method ends");
		}
	}

	@Override
	public ArrayList<Pet> getPetInfo(String userName) {
		// TODO Auto-generated method stub
		ArrayList<Pet> petInfo=new ArrayList<Pet>();
		Connection conn=ConnectDB.getConnection();
		String sql="select * from pet where Ownername=?";
		System.out.println("getPetInfo method begins");
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, userName);
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				int PetID=rs.getInt("PetID");
				String petName=rs.getString("PetName");
				String PetSex=rs.getString("PetSex");
				double PetAge=rs.getDouble("PetAge");
				String PetType=rs.getString("PetType");
				String PetKind=rs.getString("PetKind");
				
				Pet pet=new Pet(PetID, petName, userName, PetSex, PetAge, PetType,PetKind);
				petInfo.add(pet);
				
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Fail to getPetInfo");
		}finally {
			ConnectDB.closeConnection(conn);
			System.out.println("getPetInfo method ends");
		}
		return petInfo;
	}

	@Override
	public ArrayList<PetKind> getPetKind(String type) {
		// TODO Auto-generated method stub
		ArrayList<PetKind> petKinds=new ArrayList<PetKind>();
		String sql=null;
		System.out.println("type"==type);
		Connection conn=ConnectDB.getConnection();
		if (type.equals("0")) {
			 sql="select * from dog ";
			
		}
		else if (type.equals("1")) {
			sql="select * from cat ";
		}
		System.out.println("getPetKind method begins");
		 System.out.println(sql);
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				int PetKindID=rs.getInt("PetKindId");
				String petKindName=rs.getString("PetKindName");
				PetKind petKind=new PetKind(PetKindID, petKindName);
				petKinds.add(petKind);
				
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}finally {
			ConnectDB.closeConnection(conn);
			System.out.println("getPetKind method ends");
		}
		return petKinds;
	}


}
