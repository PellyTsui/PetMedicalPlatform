package dao;

import java.util.ArrayList;

import bean.Article;
import bean.Doctor;

public interface DoctorDao {
	public void addDoctor(Doctor doctor);
	public Doctor findDrByName(String name);
	public void changepwd(String username, String pwd);
	public Doctor getDoctorInfo(String username,String pwd);
    public ArrayList<Doctor> getPendingRegisterList();
    public void changeState(int id);
    public void deleteSignup(int id);
    
    public void writeArticle(Article article);
    public ArrayList<Article> getMyArticles(int did);
    public Article getArticleDetail(int aid);
}
