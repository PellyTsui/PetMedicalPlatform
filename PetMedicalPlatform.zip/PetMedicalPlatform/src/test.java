
public class test {
	public static void main(String[] args) {
		
		for(double i=1;i<12;i++){
			System.out.print(i/10+" ");
			System.out.println((int)(i));
		}
	}

}
