import java.util.Calendar;

public class test {

	public String getdays(String dedate) {
		// TODO Auto-generated method stub
		Calendar c = Calendar.getInstance();
		int year = c.get(Calendar.YEAR);
		int month = c.get(Calendar.MONTH) + 1;
		int date = c.get(Calendar.DATE);
		System.out.println("ԭ������---��" + dedate);
		String b = dedate.replace("-", "");
		System.out.println("ȥ�����ߺ�����---��" + b);

		System.out.println("8");
		String ryear = b.substring(0, 4);
		System.out.println("year--->" + ryear);
		String rmon = b.substring(4, 6);
		String rdate = b.substring(6, 8);
		System.out.println(((year - (Integer.parseInt(ryear))) * 365) + ((month - Integer.parseInt(rmon)) * 30)
				+ (date - Integer.parseInt(rdate)) + "");
		return (((year - (Integer.parseInt(ryear))) * 365) + ((month - Integer.parseInt(rmon)) * 30)
				+ (date - Integer.parseInt(rdate)) + "");

	}

	public static void main(String[] args) {

		System.out.println(new test().getdays("2016-02-14"));

		String days = new test().getdays("2015-01-01");
		// int months=Integer.parseInt(days)/30;
		int years = Integer.parseInt(days) / 360;
		int months = (Integer.parseInt(days) % 360) / 30;
		System.out.println(years + "��" + months + "��");

	}

}
