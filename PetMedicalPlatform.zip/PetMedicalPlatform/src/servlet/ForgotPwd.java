package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Doctor;
import bean.User;
import dao.DoctorDao;
import dao.DoctorDaoImpl;
import dao.UserDao;
import dao.UserDaoImpl;
import utility.EmailUtils;

/**
 * Servlet implementation class ForgotPwd
 */
@WebServlet("/ForgotPwd")
public class ForgotPwd extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ForgotPwd() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = request.getParameter("username");
		String type=request.getParameter("type");
		System.out.println("type:"+type);
		if (type.equals("0")) {
			UserDao userDao = new UserDaoImpl();
			User user = userDao.findUserByName(username);
			if (user.getUsername() == null||user.getUsername().equals("")) {
				request.setAttribute("message", "�û���������");
				request.getRequestDispatcher("UserWelcome.jsp").forward(request, response);
				return;
			}
			
			// ���������������������
			EmailUtils.sendResetPasswordEmail(user);
		}
		if (type.equals("1")) {
			DoctorDao doctorDao=new DoctorDaoImpl();
			Doctor doctor=doctorDao.findDrByName(username);
			if (doctor.getDrName()==null||doctor.getDrName().equals("")) {
				request.setAttribute("message", "�û���������");
				request.getRequestDispatcher("DrWelcome.jsp").forward(request, response);
				return;
			}
			System.out.println("mail:"+doctor.getDrMail());
			EmailUtils.sendResetPasswordEmail1(doctor);
			
		}
		
		request.setAttribute("message", "�ѷ����ʼ���ע�����䣬���½�����ͨ���ʼ��޸�����");
		
		request.getRequestDispatcher("UserWelcome.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
