package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Doctor;
import dao.DoctorDao;
import dao.DoctorDaoImpl;

/**
 * Servlet implementation class DoctorSignup
 */
@WebServlet("/DoctorSignup")
public class DoctorSignup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DoctorSignup() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());

		DoctorDao doctorDao=new DoctorDaoImpl();
		String userName=request.getParameter("userName");
		String userPwd=request.getParameter("userPwd");
		String userMail=request.getParameter("userMail");
		String phoNum=request.getParameter("phoNum");
		int locate=Integer.parseInt(request.getParameter("locate"));
		String DrHosptl=request.getParameter("DrHosptl");
		String DrGoodAt=request.getParameter("DrGoodAt");
		String DrIntro=request.getParameter("DrIntro");
		
		Doctor doctor=new Doctor(userName, userPwd, phoNum, userMail, locate, DrHosptl, DrGoodAt, DrIntro);
		doctorDao.addDoctor(doctor);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
