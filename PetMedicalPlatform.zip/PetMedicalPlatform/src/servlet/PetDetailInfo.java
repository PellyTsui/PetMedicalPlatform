package servlet;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Pet;
import bean.User;
import dao.PetDao;
import dao.PetDaoImpl;

/**
 * Servlet implementation class PetDetailInfo
 */
@WebServlet("/PetDetailInfo")
public class PetDetailInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PetDetailInfo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String pid=null;
		String type=null;
		type=request.getParameter("type");
		pid=request.getParameter("pid");
        if (!type.equals("d3d9446802a44259755d38e6d163e820")&&!type.equals("c4ca4238a0b923820dcc509a6f75849b")) {
        	String message="�Ƿ�����";
			request.setAttribute("message", message);
			request.getRequestDispatcher("Error.jsp").forward(request, response);
		}else{
			String age="��������δ��";
			PetDao petDao=new PetDaoImpl();
			if (pid!=null) {
				Pet pet=petDao.getPetDetail(Integer.parseInt(pid));
				HttpSession session=request.getSession();
			     User user=(User)session.getAttribute("user");
			     String userName=user.getUsername();
			     if (userName.equals(pet.getOwnername())) {
			    	    String sex=pet.getPetSex();
						String petSex=pet.getPetSex();
						String petMix="��������";
						String petNeuter="δ����";
						if (petSex.equals("1")) {
							petSex="�к�";
						}else if (petSex.equals("0")) {
							petSex="Ů��";
						}else {
							petSex="����ȷ���Ա�";
						}
						Date birth=pet.getBirthdate();
						String sbirth=birth.toString();
						String days=petDao.getdays(sbirth);
						int years=Integer.parseInt(days)/360;
						int months=(Integer.parseInt(days)%360)/30;
						if(years!=0&&months!=0){
						   age=years+"��"+months+"����";
						   System.out.println(age);
						}
						if (years!=0&&months==0) {
							age=years+"��" ;
							System.out.println(age);
						}
						if (years==0&months!=0) {
							age=months+"����";
							System.out.println(age);
						}
						if (years==0&months==0) {
							age="δ����";
						}
						if (pet.getNeuter().equals("1")) {
							petMix="С��Ѫ";
						}
						if (pet.getNeuter().equals("0")) {
							petMix="����";
						}
						if (pet.getNeuter().equals("1")) {
							petNeuter="�Ѿ���";
						}
						request.setAttribute("pid", pid);
						request.setAttribute("petNeuter", petNeuter);
						request.setAttribute("petMix", petMix);
						request.setAttribute("pet", pet);
						request.setAttribute("age", age);
						request.setAttribute("sex", sex);
						request.setAttribute("petSex", petSex);
						if (type.equals("c4ca4238a0b923820dcc509a6f75849b")) {
							request.getRequestDispatcher("PetModifyDetail.jsp").forward(request, response);
						}else if (type.equals("d3d9446802a44259755d38e6d163e820")) {
							request.getRequestDispatcher("PetDetailInfo.jsp").forward(request, response);
						}else {
							String message="�Ƿ�����";
							request.setAttribute("message", message);
							request.getRequestDispatcher("Error.jsp").forward(request, response);
						}					
				}else{
					String message="�Ƿ�����";
					request.setAttribute("message", message);
					request.getRequestDispatcher("Error.jsp").forward(request, response);
				}


			}

			else{
				String message="�Ƿ�����";
				request.setAttribute("message", message);
				request.getRequestDispatcher("Error.jsp").forward(request, response);
			}
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
