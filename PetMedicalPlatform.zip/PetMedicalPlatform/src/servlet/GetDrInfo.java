package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Doctor;
import dao.DoctorDao;
import dao.DoctorDaoImpl;

/**
 * Servlet implementation class GetDrInfo
 */
@WebServlet("/GetDrInfo")
public class GetDrInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetDrInfo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String type=request.getParameter("type");
		if (!type.equals("34173cb38f07f89ddbebc2ac9128303f")&&!type.equals("c16a5320fa475530d9583c34fd356ef5")&&!type.equals("6364d3f0f495b6ab9dcf8d3b5c6e0b01")) {
			request.setAttribute("message", "�Ƿ�����");
			request.getRequestDispatcher("Error.jsp").forward(request, response);
		}else{
			DoctorDao doctorDao=new DoctorDaoImpl();
			String drName=request.getParameter("drName");
			Doctor doctor=doctorDao.findDrByName(drName);
			if (doctor.getDrName()!=null) {
				doctor=doctorDao.getDoctorInfo(drName);
				request.setAttribute("doctor", doctor);
				request.setAttribute("type", type);
				request.getRequestDispatcher("ShowDrInfo.jsp").forward(request, response);
			}else{
				request.setAttribute("message", "�Ƿ�����");
				request.getRequestDispatcher("Error.jsp").forward(request, response);

			}
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
