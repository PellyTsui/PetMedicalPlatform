package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Doctor;
import dao.AdminDao;
import dao.AdminDaoImpl;

/**
 * Servlet implementation class ACmanagement
 */
@WebServlet("/ACmanagement")
public class ACmanagement extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ACmanagement() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String type=request.getParameter("type");
		String state=request.getParameter("state");
		AdminDao adminDao=new AdminDaoImpl();
		ArrayList<String> username=new ArrayList<String>();
		ArrayList<Doctor> doctors=new ArrayList<Doctor>();
		if (type.equals("1")) {
			if (state.equals("2")) {
				 username=adminDao.getUserList(1);
			}else if (state.equals("1")) {
				username=adminDao.getUserList(2);
			}
			System.out.println("userList size"+username.size());
			 request.setAttribute("username", username);
			 request.setAttribute("state", state);
			 request.setAttribute("type", type);
		}else if (type.equals("2")) {
			if (state.equals("2")) {
				doctors=adminDao.getDrList(1);
			}else if (state.equals("1")) {
				doctors=adminDao.getDrList(2);
			}
			request.setAttribute("doctors", doctors);
			request.setAttribute("state", state);
			request.setAttribute("type", type);
			System.out.println("DrList size: "+doctors.size());
		}
		request.getRequestDispatcher("AdminAC.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
