package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.AdminDao;
import dao.AdminDaoImpl;
//import dao.DoctorDao;
//import dao.DoctorDaoImpl;
import utility.EmailUtils;

/**
 * Servlet implementation class SendPendingInfoMail
 */
@WebServlet("/SendPendingInfoMail")
public class SendPendingInfoMail extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SendPendingInfoMail() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String receiveMail=request.getParameter("mail");
		String DrID=request.getParameter("id");
		String type=request.getParameter("type");
//		DoctorDao doctorDao=new DoctorDaoImpl();
		AdminDao adminDao=new AdminDaoImpl();
		if (type.equals("0")) {
			//doctorDao.changeState(Integer.parseInt(DrID));
			adminDao.changeState(Integer.parseInt(DrID));
			EmailUtils.sentPendingConfirmed(receiveMail);

		}
		if (type.equals("1")) {
			
			//doctorDao.deleteSignup(Integer.parseInt(DrID));
			adminDao.deleteSignup(Integer.parseInt(DrID));
			EmailUtils.sentPendingRefused(receiveMail);
		}
		
		request.getRequestDispatcher("GetDrSignupPendingList").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
