package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Doctor;
import bean.Query;
import dao.DoctorDao;
import dao.DoctorDaoImpl;

/**
 * Servlet implementation class GetAnswerQueryList
 */
@WebServlet("/GetAnswerQueryList")
public class GetAnswerQueryList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetAnswerQueryList() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession session=request.getSession();
		Doctor doctor=(Doctor)session.getAttribute("doctor");
		int did=doctor.getDrID();
		DoctorDao doctorDao=new DoctorDaoImpl();
		ArrayList<Query> queries=null;
		queries=doctorDao.getAnswerQueryList(did);
		request.setAttribute("queries", queries);
		request.getRequestDispatcher("DrAnswerList.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
