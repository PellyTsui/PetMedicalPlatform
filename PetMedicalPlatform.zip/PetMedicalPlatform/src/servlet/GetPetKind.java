package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.PetKind;
import dao.PetDao;
import dao.PetDaoImpl;

/**
 * Servlet implementation class GetPetKind
 */
@WebServlet("/GetPetKind")
public class GetPetKind extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String CONTENT_TYPE = "text/xml; charset=UTF-8";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetPetKind() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String type =request.getParameter("type");
		System.out.println(type);
	       response.setContentType(CONTENT_TYPE); //���÷�������Ӧ����
	       StringBuffer city = new StringBuffer("<kinds>"); //��¼����XML���Ķ���
	       ArrayList<PetKind> list=kindInit(type);
	       System.out.println(list.size());
	       for(int i=0;i<list.size();i++){
	    	   //System.out.println(list.get(i).getPname());
//	    	   city.append("<kind>"+list.get(i).getPid()+"</kind>"+"<kind>"+list.get(i).getPname()+"</kind>");
	    	   city.append("<kind>"+list.get(i).getPname()+"</kind>");
	       }
	        city.append("</kinds>");
	        PrintWriter out = response.getWriter();
	        out.print(city.toString());
	        out.flush(); //�����ˢ��
	        out.close(); //�ر������		
    }

    /*
     * ��ʼ������
     */
    public ArrayList<PetKind> kindInit(String type) {
        ArrayList<PetKind> kindList = new ArrayList<PetKind>();
        PetDao petDao=new PetDaoImpl();
        kindList=petDao.getPetKind(type);    
        return kindList;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
