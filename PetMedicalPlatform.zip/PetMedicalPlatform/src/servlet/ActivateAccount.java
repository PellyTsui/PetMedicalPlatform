package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.User;
import dao.UserDao;
import dao.UserDaoImpl;
import utility.GenerateLinkUtils;

/**
 * Servlet implementation class ActivateAccount
 */
@WebServlet("/ActivateAccount")
public class ActivateAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ActivateAccount() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("start ActivateAccount");
		String idValue = request.getParameter("id");
		String getRandomCode=request.getParameter("checkCode");
		System.out.println("id:"+idValue);
        int id = -1;  
        try {  
            id = Integer.parseInt(idValue);  
        } catch (NumberFormatException e) {  
            throw new RuntimeException("��Ч���û���");  
        }  
        
        UserDao userDao = new UserDaoImpl();
        User user = userDao.findUserById(id);// �õ�Ҫ������ʻ� 
        if (user==null) {
			request.setAttribute("message", "������ʧЧ��������ѡ�񼤻�����");
			System.out.println("user==null");
		}
        else{
        	String checkCode=user.getRandomCode();
            boolean activated=GenerateLinkUtils.verifyCheckcode(getRandomCode, checkCode);
            // У����֤���Ƿ��ע��ʱ���͵�һ�£��Դ������Ƿ񼤻���ʻ�  
            if (activated) {
            	userDao.updateUserActivate(id);
            	request.setAttribute("message", "�ɹ�����");
    		}
            else{
            	request.setAttribute("message", "������ʧЧ��������ѡ�񼤻�����");
            }
        }
        
          
          
        request.getSession().setAttribute("user", user);  
          
        request.getRequestDispatcher("UserWelcome.jsp").forward(request, response); 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
