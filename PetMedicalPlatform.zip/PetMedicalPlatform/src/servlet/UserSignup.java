package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.User;
import dao.UserDao;
import dao.UserDaoImpl;



/**
 * Servlet implementation class UserSignup
 */
@WebServlet("/UserSignup")
public class UserSignup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserSignup() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: UserSignup ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");
		UserDao userDao=new UserDaoImpl();
		String userName=request.getParameter("userName");
		String userPwd=request.getParameter("userPwd");
		String userMail=request.getParameter("userMail");
		String phoNum=request.getParameter("phoNum");
		User user=new User(userName, userPwd, userMail, phoNum,false);		
		userDao.addUser(user);
		
		User user2=userDao.findUserByName(userName);
		request.getSession().setAttribute("user", user2);
		request.getRequestDispatcher("UserMailActivated.jsp").forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
