package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Article;
import dao.DoctorDao;
import dao.DoctorDaoImpl;

/**
 * Servlet implementation class UpdateArticle
 */
@WebServlet("/UpdateArticle")
public class UpdateArticle extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateArticle() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");
		String aid=request.getParameter("aid");
		String DrId=request.getParameter("Drid");
//		String Drname=request.getParameter("Drname");
		String title=request.getParameter("title");
		String tag1=request.getParameter("tag1");
		String tag2=request.getParameter("tag2");
		String content=request.getParameter("content");
//		System.out.println("drName:"+Drname);
     	System.out.println("drID: "+DrId);
		Article article=new Article(Integer.parseInt(aid),title, tag1, tag2, content);
		DoctorDao doctorDao=new DoctorDaoImpl();
		doctorDao.updateArticle(article);
		
		request.getRequestDispatcher("GetMyArticleList?did="+Integer.parseInt(DrId)).forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
