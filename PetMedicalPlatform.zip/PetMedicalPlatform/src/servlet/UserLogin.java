package servlet;

import java.io.IOException;
//import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import bean.Pet;
import bean.User;
//import dao.PetDao;
//import dao.PetDaoImpl;
import dao.UserDao;
import dao.UserDaoImpl;
import utility.PasswordUtil;

/**
 * Servlet implementation class UserLogin
 */
@WebServlet("/UserLogin")
public class UserLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		String userName=request.getParameter("userName");
		String userPwd=request.getParameter("userPwd");
		UserDao userDao=new UserDaoImpl();
	//	PetDao petDao=new PetDaoImpl();
		User user=userDao.findUserByName(userName);

		if (user.getUsername()!=null) {
//			ArrayList<Pet> pets=petDao.getPetInfo(userName);
			String md5Pwd=user.getUserPwd();
			if (PasswordUtil.verify(userPwd, md5Pwd)) {
				request.getSession().setAttribute("user", user);
//				request.getSession().setAttribute("pets", pets);
				request.setAttribute("message", "��½�ɹ�");
				request.getRequestDispatcher("UserWelcome.jsp").forward(request, response);
			}else{
				request.setAttribute("message", "�������");
				request.setAttribute("type", "4");
				request.getRequestDispatcher("message.jsp").forward(request, response);
			}

		} else {
			request.setAttribute("message", "�û�������");
			request.setAttribute("type", "4");
			request.getRequestDispatcher("message.jsp").forward(request, response);
		}
		
		
		 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
