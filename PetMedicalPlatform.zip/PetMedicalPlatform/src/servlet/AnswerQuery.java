package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Doctor;
import dao.DoctorDao;
import dao.DoctorDaoImpl;

/**
 * Servlet implementation class AnswerQuery
 */
@WebServlet("/AnswerQuery")
public class AnswerQuery extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AnswerQuery() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
        request.setCharacterEncoding("UTF-8");
		String answer=request.getParameter("answer");
		String Trid=request.getParameter("qid");
		String username=request.getParameter("username");
		System.out.println("username: "+username);
		String petId=request.getParameter("pid");
		HttpSession session=request.getSession();
		Doctor doctor=(Doctor)session.getAttribute("doctor");
		int did=doctor.getDrID();
		String drName=doctor.getDrName();
		DoctorDao doctorDao=new DoctorDaoImpl();
		doctorDao.answerQuery(Integer.parseInt(Trid), username, did, drName,Integer.parseInt(petId), answer);
		request.getRequestDispatcher("DrAnswerList.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
