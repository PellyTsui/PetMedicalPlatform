package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.PetDao;
import dao.PetDaoImpl;

/**
 * Servlet implementation class PetModifyDetail
 */
@WebServlet("/PetModifyDetail")
public class PetModifyDetail extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PetModifyDetail() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String pid=request.getParameter("pid");
		String sex=request.getParameter("PetSex");
		String mix=request.getParameter("mix");
		String neuter=request.getParameter("neuter");
		
		PetDao petDao=new PetDaoImpl();
		petDao.modifyPet(Integer.parseInt(pid), Integer.parseInt(sex), Integer.parseInt(mix), Integer.parseInt(neuter));
		request.getRequestDispatcher("PetDetailInfo?pid="+pid+"&type=d3d9446802a44259755d38e6d163e820").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
