package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Doctor;
import dao.AdminDao;
import dao.AdminDaoImpl;
//import dao.DoctorDao;
//import dao.DoctorDaoImpl;

/**
 * Servlet implementation class GetDrSignupPendingList
 */
@WebServlet("/GetDrSignupPendingList")
public class GetDrSignupPendingList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetDrSignupPendingList() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//.getWriter().append("Served at: ").append(request.getContextPath());
//		DoctorDao doctorDao=new DoctorDaoImpl();
//		ArrayList<Doctor> pendinglist=doctorDao.getPendingRegisterList();
		AdminDao adminDao=new AdminDaoImpl();
		ArrayList<Doctor>pendinglist=adminDao.getPendingRegisterList();
		//System.out.println(pendinglist.size());
		request.setAttribute("pendinglist", pendinglist);
		request.getRequestDispatcher("AdminGetDrPendingList.jsp").forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
