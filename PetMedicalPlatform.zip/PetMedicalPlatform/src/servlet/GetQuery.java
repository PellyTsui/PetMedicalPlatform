package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDao;
import dao.UserDaoImpl;

/**
 * Servlet implementation class GetQuery
 */
@WebServlet("/GetQuery")
public class GetQuery extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetQuery() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    //response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");
		String username=request.getParameter("username");
		String pid=request.getParameter("pid");
		String type=request.getParameter("type");
		String subtype=request.getParameter("subtype");
		String title=request.getParameter("title");
		String content=request.getParameter("content");
		UserDao userDao=new UserDaoImpl();
		userDao.addQuery(username, Integer.parseInt(pid), Integer.parseInt(type), Integer.parseInt(subtype), title, content);
		String message="�ύ����ɹ�����ȴ���ҽ�ش�";
		request.setAttribute("message", message);
		request.setAttribute("type", "1");
		request.getRequestDispatcher("message.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
