package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.DoctorDao;
import dao.DoctorDaoImpl;
import dao.UserDao;
import dao.UserDaoImpl;
import utility.PasswordUtil;

/**
 * Servlet implementation class ResetPassword
 */
@WebServlet("/ResetPassword")
public class ResetPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ResetPassword() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		String userName = request.getParameter("userName");
		String newPassword = request.getParameter("userPwd");
		String md5Pwd=PasswordUtil.generate(newPassword);
		String type=request.getParameter("type");
		if (type.equals("eccbc87e4b5ce2fe28308fd9f2a7baf3")) {
			System.out.println("doctor");
			System.out.println(userName);
			DoctorDao doctorDao=new DoctorDaoImpl();
			doctorDao.changepwd(userName, md5Pwd);
			request.setAttribute("message", "��������ɹ�");
			request.setAttribute("type", "5");
			request.getRequestDispatcher("message.jsp").forward(request, response);
		}
		else if (type.equals("a87ff679a2f3e71d9181a67b7542122c")) {
			UserDao userDao = new UserDaoImpl();
			userDao.changePwd(userName, md5Pwd);
			request.setAttribute("message", "��������ɹ�");
			request.setAttribute("type", "4");
			request.getRequestDispatcher("message.jsp").forward(request, response);
		}else {
			request.setAttribute("message", "�Ƿ�����");
			request.getRequestDispatcher("Error.jsp").forward(request, response);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
