package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Pet;
import bean.User;
import dao.PetDao;
import dao.PetDaoImpl;

/**
 * Servlet implementation class PetSignup
 */
@WebServlet("/PetSignup")
public class PetSignup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PetSignup() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");
		HttpSession session=request.getSession();
		User owner=new User();
		String ownername=null;
		if (session!=null) {
			owner=(User)(session.getAttribute("user"));
			ownername=owner.getUsername();
		}
		String PetName=request.getParameter("PetName");
		String PetSex=request.getParameter("PetSex");
		if(PetSex.equals("1")){
			PetSex="��";
		}
		if (PetSex.equals("0")) {
			PetSex="��";
		}
		String PetAge=request.getParameter("PetAge");
		double petAge=Double.parseDouble(PetAge);
		String type=request.getParameter("type");
		String kind=request.getParameter("kind");
		System.out.println(ownername+", "+PetName+", "+PetSex+", "+PetAge+", " +type+"," +kind);
		
		PetDao petDao=new PetDaoImpl();
		Pet pet=new Pet(PetName, ownername, PetSex, petAge, type, kind);
		petDao.addPet(pet);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
