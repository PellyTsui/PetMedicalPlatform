package servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Pet;
import bean.User;
import dao.PetDao;
import dao.PetDaoImpl;

/**
 * Servlet implementation class PetSignup
 */
@WebServlet("/PetSignup")
public class PetSignup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PetSignup() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");
		HttpSession session=request.getSession();
		User owner=new User();
		String ownername=null;
		if (session!=null) {
			owner=(User)(session.getAttribute("user"));
			ownername=owner.getUsername();
		}
		String PetName=request.getParameter("PetName");
		String PetSex=request.getParameter("PetSex");
		String PetBirth=request.getParameter("birth");
		String PetNeuter=request.getParameter("neuter");
		String type=request.getParameter("type");
		String kind=request.getParameter("kind");
		System.out.println("petBirth:"+PetBirth);
		String PetAncestry=request.getParameter("mix");
		java.text.SimpleDateFormat formatter= new SimpleDateFormat( "yyyy-MM-dd");
	
		Date birthdate=new Date();
		try {
			birthdate = formatter.parse(PetBirth);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PetDao petDao=new PetDaoImpl();
		Pet pet=new Pet(PetName, ownername, PetSex, type, kind, birthdate, PetAncestry, PetNeuter);
		petDao.addPet(pet);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
