package servlet;

import java.io.IOException;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.DoctorDao;
import dao.DoctorDaoImpl;

/**
 * Servlet implementation class ChangeQueryState
 */
@WebServlet("/ChangeQueryState")
public class ChangeQueryState extends HttpServlet implements Servlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangeQueryState() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String qid=request.getParameter("qid");
		String state=request.getParameter("state");
		String act=request.getParameter("act");
		DoctorDao doctorDao=new DoctorDaoImpl();
		doctorDao.updateQueryState(Integer.parseInt(qid), Integer.parseInt(state));
		//request.setAttribute("act", act);
		//request.setAttribute("qid", qid);
		request.getRequestDispatcher("DrGetQueryDetail?act="+act+"&qid="+qid).forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
