package bean;

import java.util.Date;

public class Answer {
	private int taid;
	private int trid;
	private String username;
	private int did;
	private String drName;
	private int petid;
	private String tacontent;
	private Date date;
	
	public Answer(){}
	
	public Answer(int taid,int trid,String username,int did,String drName,int petid,String tacontent,Date date){
		this.taid=taid;
		this.trid=trid;
		this.username=username;
		this.did=did;
		this.petid=petid;
		this.tacontent=tacontent;
		this.date=date;
		this.drName=drName;
	}

	public int getTaid() {
		return taid;
	}

	public void setTaid(int taid) {
		this.taid = taid;
	}

	public int getTrid() {
		return trid;
	}

	public void setTrid(int trid) {
		this.trid = trid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getDid() {
		return did;
	}

	public void setDid(int did) {
		this.did = did;
	}

	public int getPetid() {
		return petid;
	}

	public void setPetid(int petid) {
		this.petid = petid;
	}

	public String getTacontent() {
		return tacontent;
	}

	public void setTacontent(String tacontent) {
		this.tacontent = tacontent;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getDrName() {
		return drName;
	}

	public void setDrName(String drName) {
		this.drName = drName;
	}
	
	
	
	

}
