package bean;

public class Doctor {
	private int DrID;
	private String DrName;
	private String DrIntro;
	private String DrGoodAt;
	private String DrHosptl;
	private int DrState;
	private String DrPwd;
	private String DrPho;
	private String DrMail;
	private int locate;
	
	public Doctor(){}
	
	public Doctor(String DrName, String DrPwd, String DrPho, String DrMail, int locate, String DrHosptl, String DrGoodAt, String DrIntro){
		this.DrName=DrName;
		this.DrPwd=DrPwd;
		this.DrPho=DrPho;
		this.DrMail=DrMail;
		this.locate=locate;
		this.DrHosptl=DrHosptl;
		this.DrGoodAt=DrGoodAt;
		this.DrIntro=DrIntro;
	}
	
	public int getDrID() {
		return DrID;
	}
	public void setDrID(int drID) {
		DrID = drID;
	}
	public String getDrName() {
		return DrName;
	}
	public void setDrName(String drName) {
		DrName = drName;
	}
	public String getDrIntro() {
		return DrIntro;
	}
	public void setDrIntro(String drIntro) {
		DrIntro = drIntro;
	}
	public String getDrGoodAt() {
		return DrGoodAt;
	}
	public void setDrGoodAt(String drGoodAt) {
		DrGoodAt = drGoodAt;
	}
	public String getDrHosptl() {
		return DrHosptl;
	}
	public void setDrHosptl(String drHosptl) {
		DrHosptl = drHosptl;
	}
	public int getDrState() {
		return DrState;
	}
	public void setDrState(int drState) {
		DrState = drState;
	}
	public String getDrPwd() {
		return DrPwd;
	}
	public void setDrPwd(String drPwd) {
		DrPwd = drPwd;
	}
	public String getDrPho() {
		return DrPho;
	}
	public void setDrPho(String drPho) {
		DrPho = drPho;
	}
	public String getDrMail() {
		return DrMail;
	}
	public void setDrMail(String drMail) {
		DrMail = drMail;
	}
	public int getLocate() {
		return locate;
	}
	public void setLocate(int locate) {
		this.locate = locate;
	}
	
	
	

}
