package bean;

import java.util.Date;

public class Article {
	private int aid;
	private int did;
	private String title;
	private String tag1;
	private String tag2;
	private String content;
	private String dname;
	private int state;
	private Date date;
	
	public Article(){}
	
	
	public Article(int did,String title,String tag1,String tag2,String content,String dname){
		this.did=did;
		this.title=title;
		this.tag1=tag1;
		this.tag2=tag2;
		this.content=content;
		this.dname=dname;
	}
	
	public Article(int aid,String titile,String tag1,String tag2,String content){
		this.aid=aid;
		this.title=titile;
		this.tag1=tag1;
		this.tag2=tag2;
		this.content=content;
	}
	
	public Article(int aid,int did, String title,String tag1,String tag2,String content,String dname, int state,Date date){
		this(did, title, tag1, tag2, content, dname);
		this.aid=aid;
		this.state=state;
		this.date=date;
	}
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public int getDid() {
		return did;
	}
	public void setDid(int did) {
		this.did = did;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTag1() {
		return tag1;
	}
	public void setTag1(String tag1) {
		this.tag1 = tag1;
	}
	public String getTag2() {
		return tag2;
	}
	public void setTag2(String tag2) {
		this.tag2 = tag2;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}


	public Date getDate() {
		return date;
	}


	public void setDate(Date date) {
		this.date = date;
	}
	
	

}
