package bean;

public class Admin {
   private int Adid;
   private String Adname;
   private String Adpwd;
   
   public Admin(){}
   
   public Admin(String Adname,String Adpwd){
	   this.Adname=Adname;
	   this.Adpwd=Adpwd;
   }

public int getAdid() {
	return Adid;
}

public void setAdid(int adid) {
	Adid = adid;
}

public String getAdname() {
	return Adname;
}

public void setAdname(String adname) {
	Adname = adname;
}

public String getAdpwd() {
	return Adpwd;
}

public void setAdpwd(String adpwd) {
	Adpwd = adpwd;
}
   
   
   
   
   
}
