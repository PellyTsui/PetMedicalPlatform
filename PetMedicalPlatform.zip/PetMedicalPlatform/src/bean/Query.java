package bean;

import java.util.Date;

public class Query {
	private int TrId;
	private String Username;
	private int pid;
	private int type;
	private int Subtype;
	private String title;
	private String content;
	private Date date;
	private int state;
	
	public Query(){}

	public int getTrId() {
		return TrId;
	}

	public void setTrId(int trId) {
		TrId = trId;
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getSubtype() {
		return Subtype;
	}

	public void setSubtype(int subtype) {
		Subtype = subtype;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}
	
	
	
	
	

}
