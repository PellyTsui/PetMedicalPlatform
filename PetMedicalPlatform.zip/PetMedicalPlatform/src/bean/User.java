package bean;

public class User {
	private String username;
	private String  userPwd;
	private String userMail;
	private String phoNum;
	
	private int userId;
	private boolean activated;
	private String randomCode;
	
	public User(){}
	
	public User(String username,String userPwd,String userMail, String phoNum,boolean activated){
		this.username=username;
		this.userPwd=userPwd;
		this.userMail=userMail;
		this.phoNum=phoNum;
		this.activated=activated;

	}
	public User(String username,String userPwd,String userMail, String phoNum,boolean activated,int userId){
		this.username=username;
		this.userPwd=userPwd;
		this.userMail=userMail;
		this.phoNum=phoNum;
		this.activated=activated;
		this.userId=userId;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserPwd() {
		return userPwd;
	}
	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}
	public String getUserMail() {
		return userMail;
	}
	public void setUserMail(String userMail) {
		this.userMail = userMail;
	}
	public String getPhoNum() {
		return phoNum;
	}
	public void setPhoNum(String phoNum) {
		this.phoNum = phoNum;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public boolean isActivated() {
		return activated;
	}

	public void setActivated(boolean activated) {
		this.activated = activated;
	}

	public String getRandomCode() {
		return randomCode;
	}

	public void setRandomCode(String randomCode) {
		this.randomCode = randomCode;
	}
	
	

}
