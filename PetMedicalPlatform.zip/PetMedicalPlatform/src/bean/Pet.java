package bean;

public class Pet {
	private String petId;
	private String petName;
	private String Ownername;
	private String petSex;
	private double petAge;
	private String petType;
	
	public Pet(){}
	
	public Pet(String petId,String petName, String Ownername,String petSex,double petAge,String petType){
		this.petId=petId;
		this.petName=petName;
		this.Ownername=Ownername;
		this.petSex=petSex;
		this.petAge=petAge;
		this.petType=petType;
	}
	
	public String getPetId() {
		return petId;
	}
	public void setPetId(String petId) {
		this.petId = petId;
	}
	public String getPetName() {
		return petName;
	}
	public void setPetName(String petName) {
		this.petName = petName;
	}
	public String getOwnername() {
		return Ownername;
	}
	public void setOwnername(String ownername) {
		Ownername = ownername;
	}
	public String getPetSex() {
		return petSex;
	}
	public void setPetSex(String petSex) {
		this.petSex = petSex;
	}
	public double getPetAge() {
		return petAge;
	}
	public void setPetAge(double petAge) {
		this.petAge = petAge;
	}
	public String getPetType() {
		return petType;
	}
	public void setPetType(String petType) {
		this.petType = petType;
	}
	
	

}
