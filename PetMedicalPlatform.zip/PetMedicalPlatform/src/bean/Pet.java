package bean;

import java.util.Date;

public class Pet {
	private int petId;
	private String petName;
	private String Ownername;
	private String petSex;
//	private double petAge;
	private String petType;
	private String petKind;
	private Date birthdate;
	private String ancestry;
	private String neuter;
	
	
	

	public Pet(){}
	
	public Pet(String petName, String Ownername,String petSex,String petType,String petKind,Date birthdate,String ancestry,String neuter){
		this.petName=petName;
		this.Ownername=Ownername;
		this.petSex=petSex;
		this.petType=petType;
		this.petKind=petKind;
		this.birthdate=birthdate;
		this.ancestry=ancestry;
		this.neuter=neuter;
	}	
	
	public Pet(int petId,String petName, String Ownername,String petSex,String petType,String petKind,Date birthdate,String ancestry,String neuter){
		this(petName, Ownername, petSex, petType, petKind, birthdate, ancestry, neuter);
		this.petId=petId;
	}
	
	public int getPetId() {
		return petId;
	}
	public void setPetId(int petId) {
		this.petId = petId;
	}
	public String getPetName() {
		return petName;
	}
	public void setPetName(String petName) {
		this.petName = petName;
	}
	public String getOwnername() {
		return Ownername;
	}
	public void setOwnername(String ownername) {
		Ownername = ownername;
	}
	public String getPetSex() {
		return petSex;
	}
	public void setPetSex(String petSex) {
		this.petSex = petSex;
	}
	public String getPetType() {
		return petType;
	}
	public void setPetType(String petType) {
		this.petType = petType;
	}
	
	public String getPetKind() {
		return petKind;
	}

	public void setPetKind(String petKind) {
		this.petKind = petKind;
	}
    
	public Date getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(Date birthdate) {
		this.birthdate = birthdate;
	}

	public String getAncestry() {
		return ancestry;
	}

	public void setAncestry(String ancestry) {
		this.ancestry = ancestry;
	}

	public String getNeuter() {
		return neuter;
	}

	public void setNeuter(String neuter) {
		this.neuter = neuter;
	}

}
