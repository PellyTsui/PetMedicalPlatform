package bean;

import java.util.Date;

public class AntiRecord {
    private int AntiId;
    private int pid;
    private String type;
    private Date date;
    
    public AntiRecord(){}
    
    public AntiRecord(int AntiId, int pid,String type,Date date){
    	this.AntiId=AntiId;
    	this.pid=pid;
    	this.type=type;
    	this.date=date;
    }

	public int getAntiId() {
		return AntiId;
	}

	public void setAntiId(int antiId) {
		AntiId = antiId;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
    
    
}
