package bean;

import java.util.Date;

public class AntiRecord {
    private int AntiId;
    private int pid;
    private int type;
    private Date date;
    
    public AntiRecord(){}
    
    public AntiRecord(int AntiId, int pid,int type,Date date){
    	this.AntiId=AntiId;
    	this.pid=pid;
    	this.type=type;
    	this.date=date;
    }

	public int getAntiId() {
		return AntiId;
	}

	public void setAntiId(int antiId) {
		AntiId = antiId;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
    
    
}
