function checktitle(){

	var idField = document.getElementById("title");
	 if(idField.value==""){
      	return false;
      	}else if(idField.value=="添加标题"){
      		return false;
      	}
	 else{
		return true;
	 }
}

function checkcontent(){
	
	var idField = document.getElementById("content");
	 if(idField.value==""){
     	return false;
     	}
	 else if(idField.value=="在此处详细描述您的问题"){
	
		 return false;
	 }
	 else{
		return true;
	 }
}

function checkpid(){
	
	 var idField = document.getElementById("pid");  
	   if(idField.value==""){
	   	document.getElementById("pidinfo").innerHTML="<font color='red'>请选择宠物";
	   	return false;
	   }else{
	  	 document.getElementById("pidinfo").innerHTML="";
	  	 return true;
	   }
}
function checkall(){
	  if(checktitle()&&checkcontent()&&checkpid()){
		  return true;
	  }else
		  return false;
}

function checkAnswer(){
	var idField = document.getElementById("answer");
	 if(idField.value==""){
    	return false;
    	}
	 else if(idField.value=="填写回答内容"){
	
		 return false;
	 }
	 else{
		return true;
	 } 
}