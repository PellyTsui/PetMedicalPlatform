	function ajaxFileUpload() {
		var idField = document.getElementById("fileToUpload");
		var _username = $.trim($("#username").val());
		var _type = $.trim($("#type").val());
		if(idField.value==""){
	     	document.getElementById("imageinfo").innerHTML="<font color='red'>请选择上传头像";
	     	return false;
		}else{
			$.ajaxFileUpload({
				url : 'upload?username='+_username+'&type='+_type,
				secureuri : false,
				fileElementId : 'fileToUpload',
				dataType : 'json',
				data : {username:_username,type:_type},
				success : function(data, status) {
					$('#viewImg').attr('src',data.picUrl);
				},
				error : function(data, status, e) {
					alert('上传出错');
				}
			})

			return false;

		}

	}