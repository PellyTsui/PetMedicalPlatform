function checkusername(){
	 var idField = document.getElementById("userName");  
     if(idField.value==""){
     	document.getElementById("info").innerHTML="<font color='red'>用户名不能为空";
     	return false;
     }else{
    	 document.getElementById("info").innerHTML="";
    	 return true;
     }
 }

function checkuserpassword(){
	var userpwd=document.getElementById("userPwd").value;
	 var pwdinfo=document.getElementById("pwdinfo");
	 if(userpwd=="")
	 {
	  pwdinfo.innerHTML="<font color='red'>密码不能为空!</font>";
	  return false;
	 }
	 else
	 {
		 document.getElementById("pwdinfo").innerHTML="";
	  return true;
	 } 
}


function login(){
	if(checkusername()&&checkuserpassword()){
		return true;
	}
		
	else
		return false;
}