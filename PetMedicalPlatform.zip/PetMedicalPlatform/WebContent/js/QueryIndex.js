document.getElementById("title").defaultValue = "给你的询问单起个简单的题目吧";

$("#title").focus(function(){
	var email_txt = $(this).val();
	if (email_txt == this.defaultValue) {
	$(this).val("");
	}
	})
	$("#title").blur(function(){
	var email_txt = $(this).val();
	if (email_txt == "") {
	$(this).val(this.defaultValue);
	}
}) 