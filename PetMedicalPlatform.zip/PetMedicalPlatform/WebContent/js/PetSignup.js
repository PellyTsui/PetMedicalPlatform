      var xmlHttp = false; //全局变量，用于记录XMLHttpRequest对象
      var checkType=false;
      var petsex=false;
      var resualt=false;
      var result=false;
      function createXMLHttpRequest() {
        if(window.ActiveXObject) { //Internet Explorer时，创建XMLHttpRequest对象的方法
          try {
            xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
          } catch(e) {
            try {
              xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
               //旧版本的Internet Explorer，创建XMLHttpRequest对象
            } catch(e) {
              window.alert("创建XMLHttpRequest对象错误"+e);
            } 
          }
        } else if(window.XMLHttpRequest) { //mozilla时，创建XMLHttpRequest对象的方法
          xmlHttp = new XMLHttpRequest();
        } 
        if(!(xmlHttp)) { //未成功创建XMLHttpRequest对象
            window.alert("创建XMLHttpRequest对象异常！");
        }  
      }

      //下拉列表项改变时的操作
      function proChange(objVal) {
    	  var idField = document.getElementById("type");
    	  if(idField.value==""){
          	document.getElementById("typeinfo").innerHTML="<font color='red'>请选择宠物种类";
          	checkType=false;}else{
          		document.getElementById("typeinfo").innerHTML="";
    		    checkType=true;
    		    //alert("here");
    	        createXMLHttpRequest(); //创建XMLHttpRequest对象
    	        document.getElementById("kind").length = 1;     //根据ID获取指定元素，并赋值
    	        xmlHttp.onreadystatechange = cityList; //指定onreadystatechange处理函数
    	        var url = "GetPetKind?type=" + objVal; //请求的URL地址
    	        xmlHttp.open("GET",url,true);
    	        xmlHttp.send(null);
    	      
          	}
 
      }
      
      function cityList() { //onreadystatechange的处理函数
        if(xmlHttp.readyState==4) {
          if(xmlHttp.status==200) {
            parseXML(xmlHttp.responseXML);     //解析服务器返回的XML数据
          }
        }
      }

      //解析xml信息，以添加地市
      function parseXML(xmlDoc) {
        var len = xmlDoc.getElementsByTagName("kind");
        //获取XML数据中所有的“city”元素对象集合
        var _citySel = document.getElementById("kind");     //根据ID获取页面中的select元素
        for(var i=0;i<len.length;i++) { //遍历XML数据并给select元素添加选项
          var opt = document.createElement("OPTION"); 
//          opt.value =xmlDoc.getElementsByTagName_r("kinds")[i].childNodes[0].firstChild.data;
//          opt.text = xmlDoc.getElementsByTagName_r("kinds")[i].childNodes[1].firstChild.data;
          
          opt.text = xmlDoc.getElementsByTagName("kind")[i].firstChild.data;
          //指定新创建元素的text属性值
          opt.value = xmlDoc.getElementsByTagName("kind")[i].firstChild.data;        
          //指定新创建元素的value属性值
          _citySel.add(opt); //为select元素添加option
        }
      }
      
      function checkPetname(){
    	  var PetName=document.getElementById("PetName").value;
    	  var info=document.getElementById("info");
    	  if(PetName==""){
    		  info.innerHTML="<font color='red'>请填写宠物名字</font>";
    		  return false;
    		 
    	  }else{
    		  info.innerHTML="";
    		  return true;
    		 
    	  }
      }
      
      function checkPetsex(){
    	  var info=document.getElementById("sexinfo");
    	  for(var i=0;i<document.getElementsByName("PetSex").length;i++){ 
      		if(document.getElementsByName("PetSex")[i].checked==true){//得到选中的单选按钮如果要得到值 那么可以：
      			petsex=true;
      		}
      		}
      	if(!petsex)
      	{
      		info.innerHTML="<font color='red'>请选择</font>";
      	}
      	return petsex;

      }
 
      /*
      function checkPetage(){
    	  var PetAge=document.getElementById("PetAge").value;
    	  var info=document.getElementById("ageinfo");
    	  if(PetAge==""){
    		  info.innerHTML="<font color='red'>请选择宠物绝育年龄</font>";
    		  return false;
    		  
    	  }else{
    		  info.innerHTML="";
    		  return true;
    		  
    	  }

      }
      */
      
    function checkKind(){
    	var idField = document.getElementById("kind");
    	 if(idField.value==""){
           	document.getElementById("kindinfo").innerHTML="<font color='red'>请选择宠物品种";
           	return false;}
    	 else{
    		 document.getElementById("kindinfo").innerHTML="";
   		     return true;
    	 }
    }
    
    function checkbirth(){
      var PetBirth=document.getElementById("birth").value;
   	  var info=document.getElementById("birthinfo");
   	  if(PetBirth==""){
   		  info.innerHTML="<font color='red'>请填写宠物出生日期</font>";
   		  return false; 
   	  }else{
//   		  if(PetBirth==null){
//   			  alert("null");
//   			  return false;
//   		  }
   		  info.innerHTML="";
   		  return true;
   		 
   	  }
    }
    
    
    function checkMix(){
    	
    	var info=document.getElementById("mixinfo");
    	for(var i=0;i<document.getElementsByName("mix").length;i++){ 
    		if(document.getElementsByName("mix")[i].checked==true){//得到选中的单选按钮如果要得到值 那么可以：
    			resualt=true;
    		}
    		}
    	if(!resualt)
    	{
    		info.innerHTML="<font color='red'>请选择</font>";
    	}
    	return resualt;
    }
    
    function checkNeuter(){
    	var info=document.getElementById("neuterinfo");
    	for(var i=0;i<document.getElementsByName("neuter").length;i++){ 
    		if(document.getElementsByName("neuter")[i].checked==true){//得到选中的单选按钮如果要得到值 那么可以：
    			result=true;
    		}
    		}
    	if(!result)
    	{
    		info.innerHTML="<font color='red'>请选择</font>";
    	}
    	return result;
    }
    
    function checkall(){
    	if(checkPetname()&&checkType&&checkKind()&&checkbirth()&&checkNeuter()){
    			return true;
    	
    	}else{
    		return false;
    	}
    }
     
    function checkAntidate(){
        var PetBirth=document.getElementById("date").value;
     	  var info=document.getElementById("dateinfo");
     	  if(PetBirth==""){
     		  info.innerHTML="<font color='red'>请选择免疫日期</font>";
     		  return false; 
     	  }else{
//     		  if(PetBirth==null){
//     			  alert("null");
//     			  return false;
//     		  }
     		  info.innerHTML="";
     		  return true;
     		 
     	  }
      }