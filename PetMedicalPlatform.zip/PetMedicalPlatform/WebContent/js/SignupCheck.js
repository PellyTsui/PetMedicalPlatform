    var req;
    var checkUsername;
    var checkUserMail;
    var checkDrmail;
    function validate() {
        //获取表单提交的内容  
        var idField = document.getElementById("userName");  
        if(idField.value==""){
        	document.getElementById("info").innerHTML="<font color='red'>用户名不能为空";
        	checkUsername="fasle";
        }else{
              	 //访问validate.do这个servlet，同时把获取的表单内容idField加入url字符串，以便传递给validate.do  
                var url = "IfUserExist?userName=" +encodeURI(idField.value);                  
                //创建一个XMLHttpRequest对象req  
                if(window.XMLHttpRequest) {  
                    //IE7, Firefox, Opera支持  
                    req = new XMLHttpRequest();  
                }else if(window.ActiveXObject) {  
                    //IE5,IE6支持   
                    req = new ActiveXObject("Microsoft.XMLHTTP");  
                }  
                /* 
                 open(String method,String url, boolean )函数有3个参数 
                 method参数指定向servlet发送请求所使用的方法，有GET,POST等 
                 boolean值指定是否异步，true为使用，false为不使用。 
                 我们使用异步才能体会到Ajax强大的异步功能。 
                 */  
                req.open("GET", url, true);  
                //onreadystatechange属性存有处理服务器响应的函数,有5个取值分别代表不同状态  
                req.onreadystatechange = callback;  
                //send函数发送请求  
                req.send(null); 
        	}
                 
        }  
          
        function callback() {  
            if(req.readyState == 4 && req.status == 200) {  
                var check = req.responseText;  
                show (check); 
            }  
        }  
          
        function show(str) {  
            if(str=="OK") { 
                var show = "<font color='green'>恭喜！！用户名可用！</font>";  
                document.getElementById("info").innerHTML = show; 
                
                checkUsername="true";
            }  
            else if( str == "NO") {  
                var show = "<font color='red'>对不起，用户名不可用！！请重新输入！</font>";  
                document.getElementById("info").innerHTML = show;
                checkUsername="fasle";
            }   
    }
    
        
        function checkDrname() {
            //获取表单提交的内容  
            var idField = document.getElementById("userName");  
            if(idField.value==""){
            	document.getElementById("info").innerHTML="<font color='red'>用户名不能为空";
            	checkUsername="fasle";
            }else{
                  	 //访问validate.do这个servlet，同时把获取的表单内容idField加入url字符串，以便传递给validate.do  
                    var url = "IfDrExist?userName=" +encodeURI(idField.value);                  
                    //创建一个XMLHttpRequest对象req  
                    if(window.XMLHttpRequest) {  
                        //IE7, Firefox, Opera支持  
                        req = new XMLHttpRequest();  
                    }else if(window.ActiveXObject) {  
                        //IE5,IE6支持   
                        req = new ActiveXObject("Microsoft.XMLHTTP");  
                    }  
                    /* 
                     open(String method,String url, boolean )函数有3个参数 
                     method参数指定向servlet发送请求所使用的方法，有GET,POST等 
                     boolean值指定是否异步，true为使用，false为不使用。 
                     我们使用异步才能体会到Ajax强大的异步功能。 
                     */  
                    req.open("GET", url, true);  
                    //onreadystatechange属性存有处理服务器响应的函数,有5个取值分别代表不同状态  
                    req.onreadystatechange = callback;  
                    //send函数发送请求  
                    req.send(null); 
            	}
                     
            }  
              
            function callback() {  
                if(req.readyState == 4 && req.status == 200) {  
                    var check = req.responseText;  
                    show (check); 
                }  
            }  
              
            function show(str) {  
                if(str=="OK") { 
                    var show = "<font color='green'>恭喜！！用户名可用！</font>";  
                    document.getElementById("info").innerHTML = show; 
                    
                    checkUsername="true";
                }  
                else if( str == "NO") {  
                    var show = "<font color='red'>对不起，用户名不可用！！请重新输入！</font>";  
                    document.getElementById("info").innerHTML = show;
                    checkUsername="fasle";
                }   
        }
         
        
    function checkuserpassword(){
    	var userpwd=document.getElementById("userPwd").value;
    	 var pwdinfo=document.getElementById("pwdinfo");
    	 if(userpwd=="")
    	 {
    	  pwdinfo.innerHTML="<font color='red'>密码不能为空!</font>";
    	  return false;
    	 }
    	 else if(userpwd.length<6)
    	 {
    	  pwdinfo.innerHTML="<font color='red'>密码至少应为六位!</font>";
    	  return false;
    	 }
    	 else if(userpwd.length>16){
    	  pwdinfo.innerHTML="<font color='red'>密码至多应为十六位!</font>"; 
    	 }
    	 else
    	 {
    	  pwdinfo.innerHTML="<font color='red'>√</font>";
    	  return true;
    	 } 
    }
    
    function checkpwdagin()  //检查确认密码
    {
     var Pwdrepeat=document.getElementById("Pwdrepeat").value;
     var pwdrepeatinfo=document.getElementById("pwdrepeatinfo");
     if(Pwdrepeat=="")
     {
    	 pwdrepeatinfo.innerHTML="<font color='red'>确认密码不能为空!</font>";
         return false;
     }
     else if(document.getElementById("Pwdrepeat").value!=document.getElementById("userPwd").value)
     {
    	 pwdrepeatinfo.innerHTML="<font color='red'>确认密码与密码不一致!</font>";
      return false;
     } 
     else
     {
    	 pwdrepeatinfo.innerHTML="<font color='red'>√</font>";
      return true;
     } 
    }
    
    function checkemail()  //检查E-mail
    {
     var userMail=document.getElementById("userMail").value;
     var mailinfo=document.getElementById("mailinfo");
     if(userMail==""){
    	 mailinfo.innerHTML="<font color='red'>请填写邮箱地址</font>";
    	 checkUserMail="fasle";
     }
     if(userMail!="")
     {
         if(userMail.indexOf("@")==-1||userMail.indexOf(".")==-1||(userMail.indexOf("@")>userMail.indexOf(".")))
         {
        	 mailinfo.innerHTML="<font color='red'>E-mail格式不正确！例：jiie@163.com</font>";
        	 checkUserMail="fasle";
         } 
         else
         {
        	     var idField = document.getElementById("userMail");  
            	 //访问validate.do这个servlet，同时把获取的表单内容idField加入url字符串，以便传递给validate.do  
                 var url = "IfMailExist?userMail=" + escape(idField.value);                  
                 //创建一个XMLHttpRequest对象req  
                 if(window.XMLHttpRequest) {  
                     //IE7, Firefox, Opera支持  
                     req = new XMLHttpRequest();  
                 }else if(window.ActiveXObject) {  
                     //IE5,IE6支持  
                     req = new ActiveXObject("Microsoft.XMLHTTP");  
                 }  
                 /* 
                  open(String method,String url, boolean )函数有3个参数 
                  method参数指定向servlet发送请求所使用的方法，有GET,POST等 
                  boolean值指定是否异步，true为使用，false为不使用。 
                  我们使用异步才能体会到Ajax强大的异步功能。 
                  */  
                 req.open("GET", url, true);  
                 //onreadystatechange属性存有处理服务器响应的函数,有5个取值分别代表不同状态  
                 req.onreadystatechange = callback1;  
                 //send函数发送请求  
                 req.send(null);                   
         
     }
     
    }
    }
    
    
    function callback1() {  
        if(req.readyState == 4 && req.status == 200) {  
            var check = req.responseText;  
            show1 (check); 
        }  
    }  
    
    function show1(str) {  
        if(str == "OK") { 
            var show = "<font color='green'>邮箱可用</font>";  
            document.getElementById("mailinfo").innerHTML = show; 
            
            checkUserMail="true";
        }  
        else if( str == "NO") {  
            var show = "<font color='red'>邮箱已被注册</font>";  
            document.getElementById("mailinfo").innerHTML = show;
            checkUserMail="fasle";
        }
        
    }   

    
    function checkphone()  //检查电话号码
    {
     var phoNum=document.getElementById("phoNum").value;
     var phoNuminfo=document.getElementById("phoNuminfo");
     if(phoNum==""){
    	 phoNuminfo.innerHTML="<font color='red'>请输入电话号码</font>";
    	 return false;
     }
     if(phoNum!="")
     {
         var reg = /^[0-9]{11}$/i;
         if(!reg.test(phoNum))
            {
        	 phoNuminfo.innerHTML="<font color='red'>只能输入11位数字！例：13595144582或08514785214</font>";
                return false;
            }
         else
         {
        	 phoNuminfo.innerHTML="<font color='red'>√</font>";
          return true;
         }
     }
     else
     {
    	 phoNuminfo.innerHTML="<font color='red'>√</font>";
         return true;
     }
    }
    
    function checkall()
    //检查所有
    {
        if(checkUsername=="true"&&checkuserpassword()&&checkpwdagin()&&checkphone()&&checkUserMail=="true"){
            	return true;
  
        }
        else{
        	return false;
        }
        
    }
    
    function checkpwd()
    //检查所有
    {
        if(checkuserpassword()&&checkpwdagin()){
            	return true;
  
        }
        else{
        	return false;
        }
        
    }
      
   function checkDrall(){
	   if(checkUsername=="true"&&checkuserpassword()&&checkpwdagin()&&checkphone()&&checkDrmail=="true"){
       	 
		   return true;
       }
      else{
    	
   	    return false;
       }
   }
   
   
   function checkDrHosptl(){
	   var idField=document.getElementById("DrHosptl").value;
	     var info=document.getElementById("DrHosptlInfo");
	     if(idField==""){
	    	 info.innerHTML="<font color='red'>请填写在职兽医院</font>";
	    	 return false;
	     }
	     else{
	       	 info.innerHTML="<font color='red'>√</font>";
	         return true;	    	 
	     }
   }
   
   function checkDrGoodAt(){
	   var idField=document.getElementById("DrGoodAt").value;
	     var info=document.getElementById("DrGoodAtinfo");
	     if(idField==""){
	    	 info.innerHTML="<font color='red'>请填写擅长领域</font>";
	    	 return false;
	     }
	     else{
	       	 info.innerHTML="<font color='red'>√</font>";
	         return true;	    	 
	     }
   }
   
   function checkDrIntro(){
	   var idField=document.getElementById("DrIntro").value;
	     var info=document.getElementById("DrIntroinfo");
	     if(idField==""){
	    	 info.innerHTML="<font color='red'>请填写自我介绍</font>";
	    	 return false;
	     }
	     else{
	       	 info.innerHTML="<font color='red'>√</font>";
	         return true;	    	 
	     }
   }
   
   function doctorSignup(){
	   if(checkDrHosptl()&&checkDrGoodAt()&&checkDrIntro()&&checkrRealname()){
		   return true;
       }
      else{
   	    return false;
       }
   }   

 
   function drMail(){
	     var userMail=document.getElementById("userMail").value;
	     var mailinfo=document.getElementById("mailinfo");
	     if(userMail==""){
	    	 mailinfo.innerHTML="<font color='red'>请填写邮箱地址</font>";
	    	 checkDrmail="fasle";
	     }
	     if(userMail!="")
	     {
	         if(userMail.indexOf("@")==-1||userMail.indexOf(".")==-1||(userMail.indexOf("@")>userMail.indexOf(".")))
	         {
	        	 mailinfo.innerHTML="<font color='red'>E-mail格式不正确！例：jiie@163.com</font>";
	        	 checkDrmail="fasle";
	         } else{
	        	 mailinfo.innerHTML="<font color='red'>√</font>";
	        	 checkDrmail="true";
	        	 }
	     }
   }
   
   
   function checkrRealname(){
	   var idField=document.getElementById("truename").value;
	     var info=document.getElementById("realnameinfo");
	     if(idField==""){
	    	 info.innerHTML="<font color='red'>请填写真实姓名</font>";
	    	 return false;
	     }
	     else{
	       	 info.innerHTML="<font color='red'>√</font>";
	         return true;	    	 
	     }
   }
   
   function checkdr(){
	   
	   if(checkphone()&&checkDrGoodAt()&&checkDrIntro()&&checkDrHosptl()){
		   return true;
       }
      else{
   	    return false;
       }
   } 